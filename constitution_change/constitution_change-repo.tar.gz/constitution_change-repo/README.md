# OSU Open Source Club Constitution Repository

This repository exists for the purposes of making incremental changes - and logging said
changes - to the official constitution of the Open Source Club at the Ohio State University.
