Stallman is down, everybody panic
