# Default Meetings

There are a couple meetings that should be the same every year.

## First Meeting - What is Open Source

## Second Meeting - Intro to the CLI

This is where you separate the geeks from the chaff.

Whichever officer is the most skilled at cli-foo should give the talk, and walk through the `.md` file in this directory (preferably in a tmux session on one pane, and do the examples in the other). They should be able to expand on why they're doing it like that, and what else they could do with that command. Try not to spend too much time on `cp`, `mkdir`, `mv`, etc. There's a lot of cool stuff to get to, and potentially this meeting could be rolled into one with the git meeting if the talk becomes very efficient. Chances are though, that the talk will go long as it is, and that not all the tools will be gotten to. Just try to do the best you can, and add whatever is appropriate to the documentation.
