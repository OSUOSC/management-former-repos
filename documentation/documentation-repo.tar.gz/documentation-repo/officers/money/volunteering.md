# Volunteering 

See E-Council for more details on how funding works.
This is the process for submitting an event to E-council and then how to record the hours.
I will be using PyOhio for this example because it is our main event of the year.

[E-council provides volunteer request documentation here.](https://ec.osu.edu/events/volunteer-requests)


## Before the Event, Register the Event

Registering the event can be done by letting the E-council president know of the event and then registering the event with E-council.
This means after contacting the president of E-council, they will send you a form with the event name and some basic information about the event.
The form does not take long to complete.
Generally you have to let E-council know that your club will be hosting an event and make them aware of it so they have it in their records.


## Volunteering at the Event

While at the event, make sure to bring the [Paper Volunteer Form](https://ec.osu.edu/sites/ec.osu.edu/files/uploads/SOV_Forms/sov_forms_general_1.doc) to get everyone's hours at the event logged. 
It's also required to get this form signed by the event coordinator.

Make sure to get this done at the event.
Although completing the paper form can be done after the event, it's highly advisable to get this done during the event and then send the forms into E-council immedietly.


## After the event

Send in Paper Volunteer Form.

There is also an [Online Volunteer Form](https://docs.google.com/forms/d/e/1FAIpQLSdmRzPfXwW7Q-4vxFzabib5vU-r7cdJp7aM79Nddbs9Gm89mA/viewform?c=0&w=1&includes_info_params=true) that needs to be completed along with the paper Volunteer Form.
This online form is a Google Form that is easiest to complete by one person after the event concludes. 
After recording all the Open Source Club members hours, the president can go in and complete the form for each Open Source member.
It is much easier than hunting everyone down and requiring them to complete the form.

