# E-Council - the source of funding

[E-Council](https://ec.osu.edu/) meets every other thursday of the semester and they are the source of funding for the club. 
The requirements for funding require the club to be active and to attend all e-council meetings for the year.


## Mailing List

E-Council provides a [mailing list](https://lists.osu.edu/mailman/listinfo/ecouncil) where all the meeting announcements and ecouncil news comes from.
This email should be read diligently to understand 


## Presentation

Once a year depending on the registration window, ours is currently the fall, the club is able to request funds from the university for funds for the year.
The announcements come through the news, and the presentation format is distributed by e-council, be on the lookout for this email.


## Volunteering

E-Council gives money based on how many hours the club and its members have volunteered. 
The price per volunteer hour changes, but in recent years it has been $50/every club volunteer hour. 
We typically get all of our hours out at PyOhio.

E-Council limits the amount of hours you can submit at 40 which would be equivalent to $2000.

See volunteering section for volunteer hours process.


