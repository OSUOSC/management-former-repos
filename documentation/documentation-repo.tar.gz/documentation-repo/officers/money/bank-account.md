# Open Source Club Bank Account

Yes we have a club bank account and yes it's funds should be managed carefully.


## Who

There should be two officers on the club bank account, the President, and the Treasurer.
Our club banks with [Fifth Third](53.com) and we use the Fifth Third on High Street. 
The address is: 1960 N High St, Columbus, OH 43201

Although there has been much back and forth between adding the advisor on the account, THE ADVISOR SHOULD NOT BE ADDED TO THE CLUB BANK ACCOUNT.

Cards should be distributed to both officers.


## Why

We use the the bank funds for pizza mostly, but we also use the funds for PyOhio Programs and other purchases throughout the semester such as new hardware and some other capital expenses.

Purchases on hardware should be thought through carefully and there should be discussion between the president and the treasurer about the needs of the club before making these large types of purchases.
