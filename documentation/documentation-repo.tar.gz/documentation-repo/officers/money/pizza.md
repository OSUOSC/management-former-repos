# Pizza

The club orders pizza every week to retain members and gain new members. 
One of the officers, currently the president's responsibility, is responsible for ordering the pizza and making sure the pizza gets to the meeting before the meetings starts.

## Order

We order from [Papa Johns on High](https://www.papajohns.com/locations/usa/oh/columbus/43201/2108-n.-high-street/220) 
  - 2108 N High St, Columbus, OH 43201 
  - (614)299-727

Make sure to set the delivery time on the order for 7PM or 7:15PM.

For a regular meeting, we usually order 6 pizzas, 3 cheese and 3 peperoni. 
The cost is around $85 for six pizzas.

The meetings we order more pizza are the first meeting of the year, and also sometimes the first meeting of the second semester.
Both of these 'special' meetings occur after the event fair.
