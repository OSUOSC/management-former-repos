---
updated: 2018-02-01
title: Transitions
---

Transitioning to new management is _hard_. I get that. This document is to make that easier. Of course, there will be things that are omitted here that will catch new officers by surprise, and this document should be updated as often as necessary to reflect what is necessary during an officer transition.

# Official Info

There are many references to "The Open Source Club" **all** around OSU. Most of these list officers and contact information that will need to be updated as often as management changes. To begin with:

- https://engineering.osu.edu/studentorgs/open-source-club
- https://activities.osu.edu/involvement/student_organizations/find_a_student_org/?i=1042&v=card&s=open+source&page=0

# Training

There is a bit of training that the officers have to go through. This is to conform to OSU's/The Union's/$(BullShit)'s/E-Council's requirements. We need to have the Club's President, VP, and Treasurer take some type of courses and go through that shit.

#### TODO: @jmoore53 ^^

# Outro

Most of the other questions that new officers may have should be answered by most of the documentation in this repo.
