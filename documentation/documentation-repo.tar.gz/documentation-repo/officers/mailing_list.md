# `opensource-announce@cse.ohio-state.edu`

This is the mailing list for the officers to keep one another abreast of ongoing developments in their respective areas.

AKA CC this address every time you want to communicate with the other officers and CYA with a paper trail. Basically any time you're setting up some _thing_ with an outside entity.

- Front Page: http://mailman.cse.ohio-state.edu/mailman/listinfo/opensource-announce
- Archives: http://mailman.cse.ohio-state.edu/mailman/private/opensource-announce/
- Moderation Interface:

## Administrators

This should be the BDFL and the Vice Chancellor

## Moderators

These should be all other officers. If necessary, the advisors can also be moderators. There would have to be extenuating circumstances to have anyone other than the officers or advisors as a moderator.

# Welcome email:

> Welcome to the OSC-officers mailing list. Or what used to be called OSC-officers, anyways.
>
> This is the internal mailing list. This isn't the 'let's hide shit-talking of the members' mailing list. It's not the 'only way I communicate' mailing list either.
>
> If it has to do with Scheduling or Administration, then it probably belongs in here. Friendly reminders and implementation discussion is welcome as well. Right now we have Kanboard - but there should always be an external task-tracking tool that the administration uses. This is not it. There aren't to be any votes for anything either.
>
> Be professional and courteous. These little shits are gunna be kept forever. They're invaluable for digging up contacts, though. It also doesn't hurt to look back for a period of time and catch yourself up to speed. And I _do_ encourage you to go through the history a bit.
>
> Enjoy your time here, promote Freedom and Liberty and Open Source to the fullest, and keep the damned webserver up and running.
>
> No man is an island. Communication is key to succeed here. And what is success? Well, leave the club a little better than you found it. That's all I can ask.

# Other Documentation

- `opensource@cse.ohio-state.edu` Public Mailing List
- Systems' Mailing List Administration documentation
