---
author: smacz
date: 2018-01-14
service: "Ansible"
description: "This document describes how to set up a server to be a CNC server for Ansible."
references: ""
todo:
  - Add volume for ansible files
---
# WeeChat Plugin

The WeeChat plugin was installed to `/usr/lib/weechat/matrix`. This is just a git repo, so it can be updated by periodically running `git pull` from that directory.

#### TODO: Make this a cron job
