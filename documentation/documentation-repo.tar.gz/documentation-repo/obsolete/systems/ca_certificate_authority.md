---
author: smacz
date: 2018-03-22
service: "CA Certificate Authority"
discription: "This document describes how to set up a CA Certificate Authority server capable of creating and signing server and user certificates with a standard workflow."
---

# Service Summary

This service provides certificates and ca-cert bundles to our servers.

## Service Type: Infrastructure

# Servers

- cacertsin01fato.adm.opensource.osu.edu
    - Accounts:
      - `ca_creator`
    - Files:
        - CA files in `/opt/CA`
    - IP Address: `10.0.3.35`
- cacertsui01fdto.dmz.opensource.osu.edu
    - Accounts:
      - `ca_creator`
    - Files:
        - ACME files in `/opt/CA`
    - IP Address: `10.0.1.67`

v2_subnet: `10.0.10.0/24`

# Firewall Rules

- firewall: pfsadmnw01bcto
  - rule: DNS Zone Transfer from DMZ Slave
    interface: WAN
    port: 53
    src: 10.0.1.33
    dst: 10.0.3.33
    protocol: IPv4 TCP
  - rule: DNS Zone Transfer from BLD Slave
    interface: WAN
    port: 53
    src: 10.0.2.33
    dst: 10.0.3.33
    protocol: IPv4 TCP
- firewall: pfsdmznw01bcto
  - rule: DNS Zone Transfer from ADM Master
    interface: WAN
    port: 53
    src: 10.0.3.33
    dst: 10.0.1.33
    protocol: IPv4 TCP
- firewall: pfsbldnw01bcto
  - rule: DNS Zone Transfer from ADM Master
    interface: WAN
    port: 53
    src: 10.0.3.33
    dst: 10.0.2.33
    protocol: IPv4 TCP

# Accounts

## Service Accounts

- `cert_manager`

# Workflow

## cacertsin01fato

- Create new certificates for services interally
- Distribute private key to server
- Distribute public key to clients

## cacertsui01fdto

- Allow cert_manager to log in to place automated Let's Encrypt verifications in.

# App Setup

## cacertsin01fato.adm.opensource.osu.edu

```
# mkdir /opt/ca && cd /opt/ca
# mkdir certs crl newcerts private csr
# chmod 700 private
# touch index.txt
# echo 1000 > serial
# cat << EOF > openssl.cnf
# OpenSSL root CA configuration file.
# Copy to `/root/ca/openssl.cnf`.

[ ca ]
# `man ca`
default_ca = CA_default

[ CA_default ]
# Directory and file locations.
dir               = /opt/ca
certs             = $dir/certs
crl_dir           = $dir/crl
new_certs_dir     = $dir/newcerts
database          = $dir/index.txt
serial            = $dir/serial
RANDFILE          = $dir/private/.rand

# The root key and root certificate.
private_key       = $dir/private/ca.key.pem
certificate       = $dir/certs/ca.cert.pem

# For certificate revocation lists.
crlnumber         = $dir/crlnumber
crl               = $dir/crl/ca.crl.pem
crl_extensions    = crl_ext
default_crl_days  = 30

# SHA-1 is deprecated, so use SHA-2 instead.
default_md        = sha256

name_opt          = ca_default
cert_opt          = ca_default
default_days      = 375
preserve          = no
policy            = policy_strict

[ policy_strict ]
# The root CA should only sign intermediate certificates that match.
# See the POLICY FORMAT section of `man ca`.
countryName             = match
stateOrProvinceName     = match
organizationName        = match
organizationalUnitName  = optional
commonName              = supplied
emailAddress            = optional

[ policy_loose ]
# Allow the intermediate CA to sign a more diverse range of certificates.
# See the POLICY FORMAT section of the `ca` man page.
countryName             = optional
stateOrProvinceName     = optional
localityName            = optional
organizationName        = optional
organizationalUnitName  = optional
commonName              = supplied
emailAddress            = optional

[ req ]
# Options for the `req` tool (`man req`).
default_bits        = 4096
distinguished_name  = req_distinguished_name
string_mask         = utf8only

# SHA-1 is deprecated, so use SHA-2 instead.
default_md          = sha256

# Extension to add when the -x509 option is used.
x509_extensions     = v3_ca

[ req_distinguished_name ]
# See <https://en.wikipedia.org/wiki/Certificate_signing_request>.
countryName                     = Country Name (2 letter code)
stateOrProvinceName             = State or Province Name
localityName                    = Locality Name
0.organizationName              = Organization Name
organizationalUnitName          = Organizational Unit Name
commonName                      = Common Name
emailAddress                    = Email Address

# Optionally, specify some defaults.
countryName_default             = US
stateOrProvinceName_default     = OH
localityName_default            = Columbus
0.organizationName_default      = OSUOSC
organizationalUnitName_default  =
emailAddress_default            =

[ v3_ca ]
# Extensions for a typical CA (`man x509v3_config`).
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid:always,issuer
basicConstraints = critical, CA:true
keyUsage = critical, digitalSignature, cRLSign, keyCertSign

[ v3_intermediate_ca ]
# Extensions for a typical intermediate CA (`man x509v3_config`).
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid:always,issuer
basicConstraints = critical, CA:true, pathlen:0
keyUsage = critical, digitalSignature, cRLSign, keyCertSign

[ usr_cert ]
# Extensions for client certificates (`man x509v3_config`).
basicConstraints = CA:FALSE
nsCertType = client, email
nsComment = "OpenSSL Generated Client Certificate"
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid,issuer
keyUsage = critical, nonRepudiation, digitalSignature, keyEncipherment
extendedKeyUsage = clientAuth, emailProtection

[ server_cert ]
# Extensions for server certificates (`man x509v3_config`).
basicConstraints = CA:FALSE
nsCertType = server
nsComment = "OpenSSL Generated Server Certificate"
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid,issuer:always
keyUsage = critical, digitalSignature, keyEncipherment
extendedKeyUsage = serverAuth

[ crl_ext ]
# Extension for CRLs (`man x509v3_config`).
authorityKeyIdentifier=keyid:always

[ ocsp ]
# Extension for OCSP signing certificates (`man ocsp`).
basicConstraints = CA:FALSE
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid,issuer
keyUsage = critical, digitalSignature
extendedKeyUsage = critical, OCSPSigning
EOF
# openssl genrsa -aes256 -out private/ca.key.pem 4096
Enter pass phrase for private/ca.key.pem:
Verifying - Enter pass phrase for private/ca.key.pem:
# chmod 400 private/ca.key.pem
# openssl req -config openssl.cnf -key private/ca.key.pem -new -x509 -days 7300 -sha256 -extensions v3_ca -out certs/ca.cert.pem
# chmod 444 certs/ca.cert.pem
```

### Create a new cert

```
# cd /opt/ca
# openssl genrsa -out private/ldapprvin01bato.key.pem 2048
# openssl req -config openssl.cnf -key private/ldapprvin01bato.key.pem -new -sha256 -out csr/ldapprvin01bato.csr.pem
# openssl ca -config openssl.cnf -extensions server_cert -days 375 -notext -md sha256 -in csr/ldapprvin01bato.csr.pem -out certs/ldapprvin01bato.cert.pem
# chmod 444 certs/ldapprvin01fato.cert.pem
```

## cacertsin01fdto.adm.opensource.osu.edu

### Make the webserver for the challenge response

```
# mkdir -p /home/cert_manager/public_html/.well-known/acme-certificates
# chown -R cert_manager:cert_manager /home/cert_manager
# chmod -R a+rX /home/cert_manager/public_html
# dnf install -y httpd
# firewall-cmd --permanent --add-service http
# sed -i 's/^User.*/User cert_manager' /etc/httpd/conf/httpd.conf
# sed -i 's/^Group.*/Group cert_manager' /etc/httpd/conf/httpd.conf
# sed -i 's/^DocumentRoot.*/DocumentRoot /home/cert_manager/public_html' /etc/httpd/conf/httpd.conf
# sed -i 's/^<Directory "\/var\/www">.*/<Directory "/home/cert_manager/public_html">' /etc/httpd/conf/httpd.conf
# systemctl enable httpd
# systemctl start httpd
```

### On the pfsense server

Install acme package

Services -> Acme Certificates

Account keys -> [Add]

- name: open source club
- description: The private key certificate for our club's SSL certs from Let's Encrypt
- Acme Server: Production ACME v1
- Email address: opensource-announce@cse.ohio-state.edu
- Account key: <private key>

Certificates -> [New]

- name osc_lets_encrypt
- Status: Active
- Acme Account open source club
- Key Size 2048
- Domain SAN list
  - domain names:
    - opensource.osu.edu
    - www.opensource.osu.edu
    - opensource.cse.ohio-state.edu
    - www.opensource.cse.ohio-state.edu
  - Method: webroot FTP
    - Server: sftp://10.0.1.67
    - username: cert_manager
    - password: <password>
    - folder: /home/cert_manager/public_html/.well-known/acme-challenge/

General settings

- Cron Entry: [X]
- Write Certificates: [X]

### Set up the pfsense server

Redirects -> HTTPtoHTTPS

- PathRegex: `^/[^.]*$`

Web Servers -> [Add]

- Enable this peer [X]
- Peer Alias: cacersui01fdto
- Peer IP: 10.0.1.67
- Peer Port: 80
- Peer Protocol: HTTP
- Peer Description: Let's Encrypt certificate proof

Mappings -> [Add]

- Enable This URI: [X]
- Group Name: cacerts
- Peers: cacertsui01fdto
- URI:
  - `^http://opensource.osu.edu/.well-known`
  - `^http://www.opensource.osu.edu/.well-known`
  - `^http://opensource.cse.ohio-state.edu/.well-known`
  - `^http://www.opensource.cse.ohio-state.edu/.well-known`

# Renewal

The renewal should take place every 60 days. Assuming that all systems are set up appropriately, this should be done automatically. However, in my experience, only a reboot of the router was able to pick up the new cert after it was generated. Even a restart of the reverse proxy on the router itself didn't allow the cert to be renewed. Future renewals should test if there is an easier way to get the new certificate to be recognized by the service.

# References

https://jamielinux.com/docs/openssl-certificate-authority/create-the-root-pair.html
https://networklessons.com/uncategorized/openssl-certification-authority-ca-ubuntu-server/
http://virtuallyhyper.com/2013/04/setup-your-own-certificate-authority-ca-on-linux-and-use-it-in-a-windows-environment/
