# Preparing the system for upgrade

Ensure your VM (or, god forbid, physical box) has >=1G of RAM.  Helps avoid a host of issues.

Use `apt-get update` and `apt-get upgrade` to get the system to the latest packages available in the current distribution.

## Back up the system

```
sudo osc_bups.sh -b <server>[...<server2>]
```

Tell all users of the system that it will be going down (more important if you have users actually using the system for significant work, but good form regardless) and make sure you're doing the upgrade at a point where downtime on the server's functionality will be acceptable.  For example, try not to take down our web server near meeting dates if at all possible.  Be ready for downtime to last until someone involved in administration can visit the physical machine, on the off-hand chance an issue arises that cannot be solved remotely.

Check the status of the packages on the system using `dpkg --audit`.  More info to follow on whether the upgrade will go through with the holds placed by MCSS.

Check `/etc/apt/sources.list` for proposed-updates and unofficial package sources.

# Upgrading the system

Change the sources in `/etc/apt/sources.list` to reflect the new version of debian, and check `/etc/apt/sources.list.d`

Start a tmux session, and if desired make the file accessible to anyone else involved in the upgrade process.

The [documentation](https://www.debian.org/releases/jessie/i386/release-notes/ch-upgrading.en.html) recommends running `script -t 2>~/upgrade-jessiestep.time -a ~/upgrade-jessiestep.script` to record the session.  Optional, but not a bad idea.  The file can be read with less or replayed with `scriptreplay ~/upgrade-jessie.time ~/upgrade-jessie.script`.

Run `apt-get update` with the new sources.list, then check whether you have disk space for the upgrade using `apt-get -o APT::Get::Trivial-Only=true dist-upgrade`.

Do a minimal system upgrade using `apt-get upgrade` then follow with a full `apt-get dist-upgrade`.  Pay attention for possible packages debian wants to remove, for conflicts, for dependency loops, etc. when doing this.  Consult the documentation linked earlier (or current version's upgrade documentation) for how to fix specific issues.

Before rebooting (to take advantage of the new kernel) it is recommended to purge old packages with `apt-get purge $(dpkg -l | awk '/^rc/ { print $2 }')`.  Then run `apt-get autoremove`.

On reboot, give the VM a few minutes, because they tend to take some time to become accessible via ssh, and then check if the services necessary are back up and running.  `apt-get upgrade` and `dist-upgrade` should stop and restart services, and they should come back up at boot time anyway, but make sure web3 is hosting the website, mail2 is forwarding mail, etc.

# Past Issues

## fail2ban

We have had a problem with `fail2ban`, claiming an error with the interpolation key ssh, fixed by changing the header of the `ssh` section to read `sshd`.

## homedir mounts

There is an issue where a regular mount complains of an invalid option. `/var/log/messages` seems to blame

```
vers=4.0
vers=4.1
vers=4.2
```

Also, it's gotta be a kerberos problem too, right? So let's try bypassing these two:

```
mount -t nfs4 -v -o sec=sys -o vers=4 stallman2:/home /home
```

Which translates to `/etc/fstab` as:

```
stallman2:/home /home nfs4 defaults,rw,soft,vers=4,sec=sys 0 0
```

This is a workaround that is probably going to be cleaned up based on some setting in some config file somewhere, but hell if I know where to start looking.

## Kernel 

We should upgrade torvalds first, because:

```
The kernel for any given DomU comes from Dom0's filesystem, not from the filesystem exported to the DomU. 
```

## LDAP URI

If `libnss-ldapd` needs to be updated, the process with prompt for the resources it needs to query ldap for, the ldap URI, the distinguished name of the search base

Resources:

- groups
- hosts
- passwd

URI: ldap://192.168.1.99
DN: dc=opensource

## install-docs

We've had to run `install-docs --install-changed` after dist-upgrade in order to fix an issue encountered during the upgrade.

## Apache configtest errors

Had to remove `/etc/apache2/mods-enabled/qos.conf` b/c of invalid conf param.

Also had to comment out lockfile param in `/etc/apache2/apache2.conf`

## Reconfiguring courier-imapd

dpkg could configure courier-imap going from jessie to stretch. Following the command given by the script, we were able to configure it and finish installing it.

# Adding a swapfile

Here is an example process for making a swapfile, where 2048k is the block size of the intended file, and there are 1000 blocks.  This produces a 2G swapfile.

```
root@mail2:/# touch swapfile
root@mail2:/# dd if=/dev/zero of=/swapfile bs=2048k count=1000
1000+0 records in
1000+0 records out
2097152000 bytes (2.1 GB, 2.0 GiB) copied, 23.6126 s, 88.8 MB/s
root@mail2:/# mkswap swapfile
mkswap: swapfile: insecure permissions 0644, 0600 suggested.
Setting up swapspace version 1, size = 2 GiB (2097147904 bytes)
no label, UUID=70ae95d4-ccfc-4456-b200-87118fca3cff
root@mail2:/# chmod 0600 swapfile 
root@mail2:/# swapon swapfile
```
