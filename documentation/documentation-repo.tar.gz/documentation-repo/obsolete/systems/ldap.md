---
author: smacz
date: 2018-01-14
service: "LDAP"
todos:
  - sudo into git repo
  - Is hand-editing slapd.d files legal?
  - Ppolicy setup
  - Replication targets setup
  - ldap require TLS
---

# Service Summary

This is the LDAP service setup with Provider-Consumer architecture.

# Service Type: Infrastructure

# Servers

- ldapprvin01bato.adm.opensource.osu.edu
    - Services:
        - LDAP (provider)
    - Files:
        - /etc/nslcd.conf
        - /etc/sssd.conf
        - /usr/local/etc/openldap/slapd.conf
    - IP: 10.0.3.34
- ldapconin01fbto.bld.opensource.osu.edu
    - Services:
        - LDAP (consumer)
    - Files:
        - /etc/nslcd.conf
        - /etc/sssd.conf
    - IP: 10.0.2.34
- ldapconin01fdto.dmz.opensource.osu.edu
    - Services:
        - LDAP (consumer)
    - Files:
        - /etc/nslcd.conf
        - /etc/sssd.conf
    - IP: 10.0.1.34

# Firewall Rules

- firewall: pfsadmnw01bcto
  - rule: LDAP Replication from DMZ Consumer
    interface: WAN
    port: 389
    src: 10.0.1.32
    dst: 10.0.3.32
    protocol: IPv4 TCP/UDP
  - rule: LDAP Replication from BLD Consumer
    interface: WAN
    port: 389
    src: 10.0.2.32
    dst: 10.0.3.32
    protocol: IPv4 TCP/UDP

# Accounts

## rootDN and admins

- `cn=oscadmin,cn=config`
- `cn=oscadmin,ou=manage,dc=opensource,dc=osu,dc=edu`
- `cn=sysadmins,ou=groups,dc=opensource,dc=osu,dc=edu`
- `cn=appadmins,ou=groups,ou=ldap,ou=applications,dc=opensource,dc=osu,dc=edu`

## Service Accounts

- ldap

# Design

## Workflow

- Change _something_ on `ldapprvsy01bato.adm.opensource.osu.edu`
- Propagate to consumer

### Posix Numbering

- User accounts: 10000-19999
- Service Accounts: 20000-29999
- Global Groups: 30000-39999
- Application Groups: 40000-49999
    - Increment by 100 per application

## Security

- Administered by any users in the `cn=admins,ou=groups,ou=ldap,ou=applications,dc=opensource,dc=osu,dc=edu` group, sysadmins, or the rootdn
- TLS certs self-signed on the LDAP provider and propagate the `cacert.pem` to the clients and consumers
    - Redoing this is required in the event of a hostname change.
- Passwords meet required complexity rules and are hashed when stored (never stored as plaintext)

## Configuration

- Configuration is done via on-line configuration (OLC)(cn=config)(slapd.d)

# App Setup

It is suggested to step through these settings on all servers in this order:

1. Initial setup
2. Bootstrap
3. ACLs
4. Replication

#### NOTE: The passwords included here need to be hashed before being put into the database. The passwords included here are placeheld with just way too many `X`'s. Please change them before running the `ldapsetup.sh` script. Create the hashed password with: `slappasswd`. This needs to be run on the node that it's being added to. Except for the `syncprov` user, which needs its password raw in the database. Luckily, the ACLs below should protect it.

## ldapprvin01bato.adm.opensource.osu.edu

### Initial Setup

```
# pkg install portmaster openssl git
# portsnap fetch extract
# portmaster net/openldap24-server
```

#### NOTE Make sure to enable PPOLICY, MEMBEROF, MDB, and REFINT compile-time options

```
# cat << EOF >> /etc/rc.conf
slapd_enable="YES"
slapd_cn_config="YES"
slapd_flags='-h "ldapi://%2fvar%2frun%2fopenldap%2fldapi/ ldap://0.0.0.0/"'
slapd_sockets="/var/run/openldap/ldapi"
EOF
# mkdir schemas && cd schemas
# git clone https://github.com/vincentvdk/ansible_inventory.git # or oscziryak fork
# cp ansible_inventory/ldap/ansible.ldif /usr/local/etc/openldap/schema/
# git clone https://github.com/jtyr/rfc2307bis.git # or oscziryak fork
# cp rfc2307bis/rfc2307bis.ldif /usr/local/etc/openldap/schema/
# mkdir /usr/local/etc/openldap/certs && chown -R ldap:ldap /usr/local/etc/openldap/certs
# mkdir -p /srv/openldap/opensource.osu.edu
# mkdir -p /srv/openldap/config
# chown -R ldap:ldap /srv/openldap
# mkdir /var/log/openldap && chown -R ldap:ldap /var/log/openldap && chmod 0750 /var/log/openldap
```

A new cert should be gotten at this point. The various files destinations are:

- `hostname.key.pem`: `/usr/local/etc/openldap/certs/serverkey.pem`
- `hostname.cert.pem`: `/usr/local/etc/openldap/certs/servercert.pem`
- `cacert.pem`: `/usr/local/etc/openldap/certs/cacert.pem`

```
# chmod 600 /usr/local/etc/openldap/certs/*.pem
# chown -R ldap:ldap /usr/local/etc/openldap/certs
# mv /usr/local/etc/openldap/slapd.conf /usr/local/etc/openldap/slapd.conf.bak
# mv /usr/local/etc/openldap/slapd.ldif /usr/local/etc/openldap/slapd.ldif.bak
# cat << EOF > /usr/local/etc/openldap/init.ldif
#
# META settings
#
dn: cn=config
objectclass: olcglobal
cn: config
olcpidfile: /var/run/openldap/slapd.pid
olcconfigdir: /usr/local/etc/openldap/slapd.d
olcloglevel: Stats
olcTLSCertificateFile: /usr/local/etc/openldap/certs/servercert.pem
olcTLSCertificateKeyFile: /usr/local/etc/openldap/certs/serverkey.pem

#
# Frontend settings
#
dn: olcdatabase={-1}frontend,cn=config
objectclass: olcdatabaseconfig
objectclass: olcFrontendConfig
olcDatabase: {-1}frontend
olcmaxderefdepth: 15
olcreadonly: FALSE
olcschemadn: cn=Subschema
olcsyncusesubentry: FALSE
olcmonitoring: FALSE

#
# Config settings
#
dn: olcdatabase=config,cn=config
objectclass: olcdatabaseconfig
olcdatabase: config
olclastmod: TRUE
olcmaxderefdepth: 15
olcreadonly: FALSE
olcrootdn: cn=oscadmin,cn=config
olcrootpw: changeme
olcsyncusesubentry: FALSE
olcmonitoring: FALSE

#
# Module loading
#
dn: cn=module,cn=config
objectclass: olcmodulelist
cn: module
olcmodulepath: /usr/local/libexec/openldap
olcmoduleload: back_mdb.la
olcmoduleload: syncprov
olcmoduleload: memberof
olcmoduleload: ppolicy
olcmoduleload: refint

#
# LMDB database definitions
#
dn: olcdatabase=mdb,cn=config
objectclass: olcdatabaseconfig
objectclass: olcmdbconfig
olcdatabase: mdb
olcsuffix: dc=opensource,dc=osu,dc=edu
olcrootdn: cn=oscadmin,dc=opensource,dc=osu,dc=edu
olcrootpw: changeme
olcdbdirectory: /srv/openldap/opensource.osu.edu
olcdbindex: objectclass eq

dn: olcDatabase={1}mdb,cn=config
objectClass: olcDatabaseConfig
objectClass: olcMdbConfig
olcDatabase: {1}mdb
olcDbDirectory: /srv/openldap/opensource.osu.edu
olcSuffix: dc=opensource,dc=osu,dc=edu
olcAddContentAcl: FALSE
olcLastMod: TRUE
olcMaxDerefDepth: 15
olcReadOnly: FALSE
olcRootDN: cn=oscadmin,dc=opensource,dc=osu,dc=edu
olcRootPW: WEg2J4c5cj5gmBUA
olcSyncUseSubentry: FALSE
olcMonitoring: FALSE
olcDbNoSync: FALSE
olcDbMaxReaders: 0
olcDbMaxSize: 10485760
olcDbMode: 0600
olcDbSearchStack: 16
olcDbRtxnSize: 10000
EOF
# slapadd -F /usr/local/etc/openldap/slapd.d -b cn=config -l /usr/local/etc/openldap/init.ldif
# cd /usr/local/etc/openldap/schema && curl -O https://raw.githubusercontent.com/Lullabot/openldap-schema/master/sudo.ldif && cd
# slapadd -F /usr/local/etc/openldap/slapd.d -b cn=config -l /usr/local/etc/openldap/schema/sudo.ldif
# slapadd -F /usr/local/etc/openldap/slapd.d -b cn=config -l /usr/local/etc/openldap/schema/ppolicy.ldif
# slapadd -F /usr/local/etc/openldap/slapd.d -b cn=config -l /usr/local/etc/openldap/schema/core.ldif
# slapadd -F /usr/local/etc/openldap/slapd.d -b cn=config -l /usr/local/etc/openldap/schema/cosine.ldif
# slapadd -F /usr/local/etc/openldap/slapd.d -b cn=config -l /usr/local/etc/openldap/schema/inetorgperson.ldif
# slapadd -F /usr/local/etc/openldap/slapd.d -b cn=config -l /usr/local/etc/openldap/schema/ansible.ldif
# slapadd -F /usr/local/etc/openldap/slapd.d -b cn=config -l /usr/local/etc/openldap/schema/rfc2307bis.ldif
# cat << EOF > /usr/local/etc/openldap/modules.ldif
#
# Syncprov config
#
dn: olcoverlay=syncprov,olcdatabase={1}mdb,cn=config
objectclass: olcsyncprovconfig
objectclass: olcoverlayconfig
objectclass: olcconfig
olcoverlay: syncprov
olcspcheckpoint: 100 10

#
# MemberOf config
#
dn: olcoverlay=memberof,olcdatabase={1}mdb,cn=config
objectclass: olcmemberof
objectclass: olcoverlayconfig
objectclass: olcconfig
olcoverlay: memberof
olcmemberofdangling: ignore
olcmemberofrefint: TRUE
olcMemberOfGroupOC: groupofnames
olcmemberofmemberad: member
olcMemberOfMemberOfAD: memberOf

#
# Refint config
#
dn: olcoverlay=refint,olcdatabase={1}mdb,cn=config
objectclass: olcrefintconfig
objectclass: olcoverlayconfig
objectclass: olcconfig
olcoverlay: refint

#
# Password Policy Overlay
#
dn: olcoverlay=ppolicy,olcdatabase={1}mdb,cn=config
objectclass: olcppolicyconfig
olcoverlay: ppolicy
olcPPolicyDefault: cn=ppolicydefault,ou=manage,dc=opensource,dc=osu,dc=edu
olcPPolicyHashCleartext: FALSE
olcPPolicyUseLockout: FALSE
olcPPolicyForwardUpdates: FALSE
EOF
# slapadd -F /usr/local/etc/openldap/slapd.d -b cn=config -l /usr/local/etc/openldap/modules.ldif
```

We should hash passwords so they're encrypted at rest. Of course, we _could_ be very complex and use the OS's `crypt(3)` function, but:

> Since this scheme uses the operating system's crypt(3) hash function, it is therefore operating system specific.

Since our LDAP provider server is based on FreeBSD, and our LDAP consumer server is a Fedora server, we're going to be simple here and just rely on OpenLDAP's `{SSHA}` hash functionality. Since this is default, we don't have to specify it anywhere. We can check to see that our `userPassword`'s are hashed by `base64`-decoding the text:

```
# echo XXXXXXXXXXXXXXXXXXXXXX= | openssl base64 -d
{SSHA}XXXXXXXXXXXXXXXXX
```

```
# cat << EOF > opensource_db.ldif
#
# Add OSUOSC baseDN
#
dn: dc=opensource,dc=osu,dc=edu
objectclass: dcobject
objectclass: organization
o: Open Source Club
dc: opensource

#
# Add manage OU
#
dn: ou=manage,dc=opensource,dc=osu,dc=edu
objectclass: organizationalunit
ou: manage

#
# Add rootDN
#
dn: cn=oscadmin,ou=manage,dc=opensource,dc=osu,dc=edu
objectclass: simplesecurityobject
objectclass: organizationalrole
cn: oscadmin

#
# Add ppolicy defaults
#
dn: cn=ppolicydefault,ou=manage,dc=opensource,dc=osu,dc=edu
objectclass: pwdPolicy
objectclass: person
objectclass: top
cn: ppolicydefault
sn: ppolicydefault
pwdAttribute: userPassword
pwdCheckQuality: 0
pwdMinAge: 0
pwdMaxAge: 0
pwdMinLength: 8
pwdInHistory: 5
pwdMaxFailure: 3
pwdFailureCountInterval: 0
pwdLockout: TRUE
pwdLockoutDuration: 0
pwdAllowUserChange: TRUE
pwdExpireWarning: 0
pwdGraceAuthNLimit: 0
pwdMustChange: FALSE
pwdSafeModify: FALSE
EOF
# slapadd -F /usr/local/etc/openldap/slapd.d -b dc=opensource,dc=osu,dc=edu -l /usr/local/etc/openldap/new_ou.ldif
# service slapd start
```

#### NOTE: To get debug messages if they're not showing up in the logs, run the command `/usr/local/libexec/slapd -d1` to output debug messages to the terminal.

If at any point you need to start configuration over from scratch, clean out the various directories with the commands below:

```
# rm -rf /srv/openldap/opensource.osu.edu/*
# rm -rf /srv/openldap/config/*
# rm -rf /usr/local/etc/openldap/slapd.d/*
```

Test locally:

```
# cat << EOF > /usr/local/etc/openldap/ldap.conf
BASE        dc=opensource,dc=osu,dc=edu
URI         ldap://10.0.3.40
TLSCACERT   /usr/local/etc/openldap/certs/cacert.pem
EOF
# ldapsearch -vxZZWD cn=oscadmin,ou=manage,dc=opensource,dc=osu,dc=edu -b dc=opensource,dc=osu,dc=edu
# ldapsearch -vxZZWD cn=oscadmin,cn=config -b cn=config
Enter LDAP Password:
```

### Bootstrap

Base OUs:

```
# cat << EOF > ~/bootstrap.ldif
dn: dc=opensource,dc=osu,dc=edu
dc: opensource
o: Open Source Club's base for the network LDAP server
objectclass: top
objectclass: dcObject
objectclass: organization

dn: ou=people,dc=opensource,dc=osu,dc=edu
objectclass: organizationalUnit
ou: people

dn: ou=svcaccts,dc=opensource,dc=osu,dc=edu
objectclass: organizationalUnit
ou: people

dn: ou=groups,dc=opensource,dc=osu,dc=edu
objectclass: organizationalUnit
ou: groups

dn: ou=hosts,dc=opensource,dc=osu,dc=edu
objectclass: organizationalUnit
ou: hosts

dn: ou=sudoers,dc=opensource,dc=osu,dc=edu
objectclass: organizationalUnit
ou: sudoers

dn: ou=applications,dc=opensource,dc=osu,dc=edu
objectclass: organizationalUnit
ou: applications

dn: cn=jmphostsy01fato,ou=hosts,dc=opensource,dc=osu,dc=edu
objectclass: device
objectclass: ipHost
objectClass: ansibleHost
ipHostNumber: 10.0.3.192
cn: jmphostsp01fato

dn: cn=officers,ou=groups,dc=opensource,dc=osu,dc=edu
objectclass: posixGroup
objectclass: groupofnames
cn: officers
gidnumber: 30000
# Start with oscadmin as `groupofnames` cannot be empty, even with rfc2307bis,
# because groupofnames as implemented in openldap has "MUST member" hard-coded
member: cn=oscadmin,ou=manage,dc=opensource,dc=osu,dc=edu

dn: cn=sysadmins,ou=groups,dc=opensource,dc=osu,dc=edu
objectclass: posixGroup
objectclass: groupofnames
cn: sysadmins
gidnumber: 30001
# Start with oscadmin as `groupofnames` cannot be empty, even with rfc2307bis,
# because groupofnames as implemented in openldap has "MUST member" hard-coded
member: cn=oscadmin,ou=manage,dc=opensource,dc=osu,dc=edu

dn: cn=sysadmins,ou=sudoers,dc=opensource,dc=osu,dc=edu
objectclass: sudorole
cn: sysadmins
sudouser: %sysadmins
sudohost: ALL
sudorunas: ALL
sudocommand: ALL

dn: cn=appadmins,ou=sudoers,dc=opensource,dc=osu,dc=edu
objectclass: sudorole
cn: appadmins
sudouser: %appadmins
sudohost: ALL
sudorunas: ALL
sudocommand: ALL
EOF
# ldapadd -vxZZWD "cn=oscadmin,ou=manage,dc=opensource,dc=osu,dc=edu" -f bootstrap.ldif
```

Application groups:

```
# cat << EOF > application_groups.ldif
dn: ou=jumphost,ou=applications,dc=opensource,dc=osu,dc=edu
objectClass: organizationalunit
ou: jumphost

dn: ou=groups,ou=jumphost,ou=applications,dc=opensource,dc=osu,dc=edu
objectClass: organizationalunit
ou: groups

dn: cn=apphostlogins,ou=groups,ou=jumphost,ou=applications,dc=opensource,dc=osu,dc=edu
objectClass: groupofnames
objectClass: posixgroup
cn: apphostlogins
gidnumber: 40000
# Start with oscadmin as `groupofnames` cannot be empty, even with rfc2307bis,
# because groupofnames as implemented in openldap has "MUST member" hard-coded
member: cn=oscadmin,ou=manage,dc=opensource,dc=osu,dc=edu

dn: cn=appadmins,ou=groups,ou=jumphost,ou=applications,dc=opensource,dc=osu,dc=edu
objectClass: groupofnames
objectClass: posixgroup
cn: appadmins
gidnumber: 40001
# Start with oscadmin as `groupofnames` cannot be empty, even with rfc2307bis,
# because groupofnames as implemented in openldap has "MUST member" hard-coded
member: cn=oscadmin,ou=manage,dc=opensource,dc=osu,dc=edu

dn: cn=appsvcaccts,ou=groups,ou=jumphost,ou=applications,dc=opensource,dc=osu,dc=edu
objectClass: groupofnames
objectClass: posixgroup
cn: appsvcaccts
gidnumber: 40002
# Start with oscadmin as `groupofnames` cannot be empty, even with rfc2307bis,
# because groupofnames as implemented in openldap has "MUST member" hard-coded
member: cn=oscadmin,ou=manage,dc=opensource,dc=osu,dc=edu

dn: cn=apphosts,ou=groups,ou=jumphost,ou=applications,dc=opensource,dc=osu,dc=edu
objectClass: groupofnames
objectclass: ansiblegroup
cn: apphosts
# Start with oscadmin as `groupofnames` cannot be empty, even with rfc2307bis,
# because groupofnames as implemented in openldap has "MUST member" hard-coded
member: cn=oscadmin,ou=manage,dc=opensource,dc=osu,dc=edu

dn: ou=website,ou=applications,dc=opensource,dc=osu,dc=edu
objectClass: organizationalunit
ou: website

dn: ou=groups,ou=website,ou=applications,dc=opensource,dc=osu,dc=edu
objectClass: organizationalunit
ou: groups

dn: cn=apphostlogins,ou=groups,ou=website,ou=applications,dc=opensource,dc=osu,dc=edu
objectClass: groupofnames
objectClass: posixgroup
cn: apphostlogins
gidnumber: 40100
# Start with oscadmin as `groupofnames` cannot be empty, even with rfc2307bis,
# because groupofnames as implemented in openldap has "MUST member" hard-coded
member: cn=oscadmin,ou=manage,dc=opensource,dc=osu,dc=edu

dn: cn=appadmins,ou=groups,ou=website,ou=applications,dc=opensource,dc=osu,dc=edu
objectClass: groupofnames
objectClass: posixgroup
cn: appadmins
gidnumber: 40101
# Start with oscadmin as `groupofnames` cannot be empty, even with rfc2307bis,
# because groupofnames as implemented in openldap has "MUST member" hard-coded
member: cn=oscadmin,ou=manage,dc=opensource,dc=osu,dc=edu

dn: cn=appsvcaccts,ou=groups,ou=website,ou=applications,dc=opensource,dc=osu,dc=edu
objectClass: groupofnames
objectClass: posixgroup
cn: appsvcaccts
gidnumber: 40102
# Start with oscadmin as `groupofnames` cannot be empty, even with rfc2307bis,
# because groupofnames as implemented in openldap has "MUST member" hard-coded
member: cn=oscadmin,ou=manage,dc=opensource,dc=osu,dc=edu

dn: cn=apphosts,ou=groups,ou=website,ou=applications,dc=opensource,dc=osu,dc=edu
objectClass: groupofnames
objectclass: ansiblegroup
cn: apphosts
# Start with oscadmin as `groupofnames` cannot be empty, even with rfc2307bis,
# because groupofnames as implemented in openldap has "MUST member" hard-coded
member: cn=oscadmin,ou=manage,dc=opensource,dc=osu,dc=edu
EOF
# ldapadd -vxZZWD "cn=oscadmin,ou=manage,dc=opensource,dc=osu,dc=edu" -f application_groups.ldif
```

CSECS Account:

```
# cat < EOF >> csecs_acct.ldif
dn: uid=csecs,ou=people,dc=opensource,dc=osu,dc=edu
cn: CSE IT Dept Login Account
sn: ETS
objectclass: person
objectclass: posixAccount
objectclass: shadowAccount
uid: csecs
userpassword: changeme
uidnumber: 19999
gidnumber: 19999
gecos: CSE IT Dept Login Account
loginShell: /bin/bash
homeDirectory: /home/csecs
shadowMax: 999999

dn: cn=csecs,ou=groups,dc=opensource,dc=osu,dc=edu
objectclass: posixGroup
objectclass: groupofnames
cn: test_user
gidnumber: 19999
member: uid=csecs,ou=people,dc=opensource,dc=osu,dc=edu

dn: cn=csecs,ou=sudoers,dc=opensource,dc=osu,dc=edu
objectclass: sudorole
cn: csecs
sudouser: #csecs
sudoHost: ALL
sudoCommand: ALL
sudoRunAsUser: ALL
EOF
# ldapadd -vxZZWD "cn=oscadmin,ou=manage,dc=opensource,dc=osu,dc=edu" -f application_groups.ldif
```

New Host:

```
# cat << EOF > new_host.ldif
EOF
# ldapadd -vxZZWD "cn=oscadmin,ou=manage,dc=opensource,dc=osu,dc=edu" -f new_host.ldif
```

### Replication

```
# cat < EOF > replication.ldif
dn: cn=ldaprepl,ou=manage,dc=opensource,dc=osu,dc=edu
objectclass: organizationalrole
objectclass: simplesecurityobject
description: "Account for LDAP replication"
cn: ldaprepl
userPassword: changeme
EOF
# ldapadd -vxZZWD "cn=oscadmin,ou=manage,dc=opensource,dc=osu,dc=edu" -f ~/replication.ldif
```

### Security and Cleanup

We want to have sane default ACLs. Here's what we're going to do:

```
dn: olcDatabase={1}mdb,cn=config
changetype: modify
# Start by deleting all the existing ACLs. This is so that we can re-add this file over and over for testing.
delete: olcAccess
olcAccess: {4}
-
delete: olcAccess
olcAccess: {3}
-
delete: olcAccess
olcAccess: {2}
-
delete: olcAccess
olcAccess: {1}
-
delete: olcAccess
olcAccess: {0}
-
# Allow everything in this database to be managed by anyone in the `sysadmins` group.
add: olcAccess
olcAccess: {0}to *
 by group.exact="cn=sysadmins,ou=groups,dc=opensource,dc=osu,dc=edu" manage
 by dn.exact="cn=ldaprepl,ou=manage,dc=opensource,dc=osu,dc=edu" read
 by * break
-
# Allow binding to anything that has a password. Allow itself to change the passwd (and sysadmins as shown above), but nothing by nobody else.
add: olcAccess
olcAccess: {1}to attrs=userPassword
 by self write
 by anonymous auth
 by * none
-
# This one I'm kinda proud of. Every `ou` underneath `ou=applications` is an app that has `cn=admins` and `cn=hosts` set up when everything else is set up for a new app. This allows every entry in `cn=admins` to control everything in the app directory. This should include user accounts who are going to administrate the application, as well as authenticated service accounts that need any more than read access.
add: olcAccess
olcAccess: {2}to dn.regex=".*ou=([^,]+),ou=applications,dc=opensource,dc=osu,dc=edu$"
 by group.expand="cn=admins,ou=$1,ou=applications,dc=opensource,dc=osu,dc=edu" manage
 by users read
 by * none
-
# We want to protect the security of the accounts and things we use to manage the LDAP database. So far we have the rootDN in there, the ldaprepl user (which already has read everywhere), and the password policy configuration. We may need more access for the password policy config, but I'm not sure at this point.
add: olcaccess
olcaccess: {3}to dn.subtree="ou=manage,dc=opensource,dc=osu,dc=edu"
 by * none
-
# All children of `dc=opensource,dc=osu,dc=edu` should be readable by all users if it hasn't matched any of the above rules already, which would be `ou=hosts`, `ou=people`, `ou=groups`, etc. This is the same as `cat`ting `/etc/passwd` and getting the same info there. If this is too wide-open, then we can add more above. But for now, I'd _love_ to call this shit finished, as I've spent >50 hours on LDAP already. Ugh. Worth it tho!
add: olcAccess
olcAccess: {4}to *
 by users read
 by anonymous none

dn: olcDatabase={0}config,cn=config
changetype: modify
# Allow everything in this database to be managed by anyone in the "sysadmins" group.
add: olcAccess
olcAccess: {0}to *
 by group.exact="cn=sysadmins,ou=groups,dc=opensource,dc=osu,dc=edu" manage
 by * break
-
# Allow everything in this database to be managed by anyone in the "sysadmins" group.
add: olcAccess
olcAccess: {1}to *
 by * none

dn: olcDatabase={-1}frontend,cn=config
changetype: modify
# Allow everything in this database to be managed by anyone in the "sysadmins" group.
add: olcAccess
olcAccess: {0}to *
 by group.exact="cn=sysadmins,ou=groups,dc=opensource,dc=osu,dc=edu" manage
 by * break
-
# Disallow everything else, except for the rootdn, since when using the rootdn, all ACL's are skipped.
add: olcAccess
olcAccess: {1}to *
 by * none
```

#### NOTE: If you want to make the formatting easier to read, at the end of every logical separation (each `by <who> <what>`) leave one space at the end of the line, and start the next rule with one space at the beginning of the next line.

Make sure these are correct, and all other ACLs are deleted. You can manually go into `/etc/openldap/slapd.d/cn=config/` and edit the database file in there to make it correct if something gets messed up. Like you can't `ldapsearch` the entirety of the `cn=config` database because you've locked yourself out! It's OK, fix that file, and restart `slapd`. It should fix itself. If it hasn't, then you did something wrong. Check the file again and fix it right this time!

#### NOTE: From [OpenLDAP Faq-O-Matic](http://www.openldap.org/faq/data/cache/320.html) and [Notes Wiki](http://sbarjatiya.com/notes_wiki/index.php/Configuring_ACLs_in_openLDAP_server)

#### NOTE: These ACLs do not replicate. Any change made to these must be also made on all of the consumer servers.

## ldapconin01bbdh.bld.opensource.osu.edu

### Setup

```
# dnf install -y git openldap openldap-servers openldap-clients
# mkdir -p /srv/openldap/opensource.osu.edu && chown -R ldap:ldap /srv/openldap
# mkdir ~/schemas && cd ~/schemas
# git clone https://github.com/vincentvdk/ansible_inventory.git # or oscziryak fork
# cp ansible_inventory/ldap/ansible.ldif /etc/openldap/schema/
# git clone https://github.com/jtyr/rfc2307bis.git # or oscziryak fork
# cp rfc2307bis/rfc2307bis.ldif /etc/openldap/schema/
# cd /etc/openldap/schema && curl -O https://raw.githubusercontent.com/Lullabot/openldap-schema/master/sudo.ldif && cd ~/schemas
```

A new cert should be gotten at this point. The various files destinations are:

- `hostname.key.pem`: `/usr/local/etc/openldap/certs/serverkey.pem`
- `hostname.cert.pem`: `/usr/local/etc/openldap/certs/servercert.pem`
- `cacert.pem`: `/usr/local/etc/openldap/certs/cacert.pem`

Don't forget to edit `/etc/openldap/ldap.conf` to reflect the correct location of the `cacert`, otherwise any `ldap*` command will complain that the cert isn't trusted. Also, the key should be owned by `ldap` and world-readable, except for the key, which should only be read-only by ldap.

```
# rm -rf /etc/openldap/slapd.d/*
```

### Policies

```
# cat << EOF > /root/ldifs/init.ldif
#
# META settings
#
dn: cn=config
objectclass: olcglobal
cn: config
olcpidfile: /var/run/openldap/slapd.pid
olcconfigdir: /etc/openldap/slapd.d
olcloglevel: Stats
olcTLSCertificateFile: /etc/openldap/certs/servercert.pem
olcTLSCertificateKeyFile: /etc/openldap/certs/serverkey.pem

#
# Frontend settings
#
dn: olcdatabase={-1}frontend,cn=config
objectclass: olcdatabaseconfig
objectclass: olcFrontendConfig
olcDatabase: {-1}frontend
olcmaxderefdepth: 15
olcreadonly: FALSE
olcschemadn: cn=Subschema
olcsyncusesubentry: FALSE
olcmonitoring: FALSE

#
# Config settings
#
dn: olcdatabase={0}config,cn=config
objectclass: olcdatabaseconfig
olcdatabase: config
olclastmod: TRUE
olcmaxderefdepth: 15
olcreadonly: FALSE
olcrootdn: cn=oscadmin,cn=config
olcrootpw: changeme
olcsyncusesubentry: FALSE
olcmonitoring: FALSE

#
# Module loading
#
dn: cn=module,cn=config
objectclass: olcmodulelist
cn: module
olcmodulepath: /usr/lib64/openldap
olcmoduleload: back_mdb.la
olcmoduleload: syncprov
olcmoduleload: memberof
olcmoduleload: ppolicy
olcmoduleload: refint

#
# LMDB database definitions
#
dn: olcDatabase={1}mdb,cn=config
objectClass: olcDatabaseConfig
objectClass: olcMdbConfig
olcDatabase: {1}mdb
olcDbDirectory: /srv/openldap/opensource.osu.edu
olcSuffix: dc=opensource,dc=osu,dc=edu
olcAddContentAcl: FALSE
olcLastMod: TRUE
olcMaxDerefDepth: 15
olcRootDN: cn=oscadmin,ou=manage,dc=opensource,dc=osu,dc=edu
olcRootPW: changeme
olcdbindex: objectclass eq
olcSyncUseSubentry: FALSE
olcMonitoring: FALSE
olcDbNoSync: FALSE
olcDbMaxReaders: 0
olcDbMaxSize: 10485760
olcDbMode: 0600
olcDbSearchStack: 16
olcDbRtxnSize: 10000
olcReadOnly: TRUE
EOF
# cat << EOF > modules.ldif
#
# MemberOf config
#
dn: olcoverlay=memberof,olcdatabase={1}mdb,cn=config
objectclass: olcmemberof
objectclass: olcoverlayconfig
objectclass: olcconfig
olcoverlay: memberof
olcmemberofdangling: ignore
olcmemberofrefint: TRUE
olcMemberOfGroupOC: groupofnames
olcmemberofmemberad: member
olcMemberOfMemberOfAD: memberOf

#
# Refint config
#
dn: olcoverlay=refint,olcdatabase={1}mdb,cn=config
objectclass: olcrefintconfig
objectclass: olcoverlayconfig
objectclass: olcconfig
olcoverlay: refint
olcRefintAttribute: memberof member manager owner

#
# Password Policy Overlay
#
dn: olcoverlay=ppolicy,olcdatabase={1}mdb,cn=config
objectclass: olcppolicyconfig
objectclass: olcoverlayconfig
objectclass: olcconfig
olcoverlay: ppolicy
olcPPolicyDefault: cn=ppolicydefault,ou=manage,dc=opensource,dc=osu,dc=edu
olcPPolicyHashCleartext: FALSE
olcPPolicyUseLockout: FALSE
olcPPolicyForwardUpdates: FALSE
EOF
# cat << EOF > syncrepl.ldif
#
# Syncrepl config
#
dn: olcDatabase={1}mdb,cn=config
changetype: modify
replace: olcSyncrepl
olcSyncrepl: {0}rid=000
  provider=ldap://ldapprvin01bato.adm.opensource.osu.edu
  type=refreshonly
  retry="5 5 300 +"
  searchbase="dc=opensource,dc=osu,dc=edu"
  attrs="*,+"
  bindmethod=simple
  binddn="cn=ldaprepl,ou=manage,dc=opensource,dc=osu,dc=edu"
  credentials=XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
EOF
# cat << EOF > changepasswd.ldif
dn: olcDatabase={1}mdb,cn=config
changetype: modify
replace: olcRootPW
olcRootPW: {SSHA}XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

dn: olcDatabase={0}config,cn=config
changetype: modify
replace: olcRootPW
olcRootPW: {SSHA}XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
EOF
# cat << EOF > ldapsetup
#!/bin/sh

systemctl stop slapd
rm -rf /etc/openldap/slapd.d/*
slapadd -F /etc/openldap/slapd.d -b cn=config -l init.ldif
slapadd -F /etc/openldap/slapd.d -b cn=config -l /etc/openldap/schema/sudo.ldif
slapadd -F /etc/openldap/slapd.d -b cn=config -l /etc/openldap/schema/ppolicy.ldif
slapadd -F /etc/openldap/slapd.d -b cn=config -l /etc/openldap/schema/core.ldif
slapadd -F /etc/openldap/slapd.d -b cn=config -l /etc/openldap/schema/cosine.ldif
slapadd -F /etc/openldap/slapd.d -b cn=config -l /etc/openldap/schema/inetorgperson.ldif
slapadd -F /etc/openldap/slapd.d -b cn=config -l /etc/openldap/schema/ansible.ldif
slapadd -F /etc/openldap/slapd.d -b cn=config -l /etc/openldap/schema/rfc2307bis.ldif
slapadd -F /etc/openldap/slapd.d -b cn=config -l modules.ldif
chown -R ldap:ldap /etc/openldap/slapd.d
systemctl start slapd
ldapmodify -vxZZD "cn=oscadmin,cn=config" -w changeme -f syncrepl.ldif
ldapmodify -vxZZD "cn=oscadmin,cn=config" -w changeme -f changepasswd.ldif
ldapwhoami -vxZZWD "cn=oscadmin,cn=config"
EOF
# chmod +x ./ldapsetup.sh
# ./ldapsetup.sh
```

### ACLs

It's probably best to do an `ldapwhoami` with a sysadmin or an `ldapadmin` user just to make sure that you'll be able to auth after you apply these new ACLs.

We want to have sane default ACLs. Here's what we're going to do:

```
dn: olcDatabase={1}mdb,cn=config
changetype: modify
# Start by deleting all the existing ACLs. This is so that we can re-add this file over and over for testing.
delete: olcAccess
olcAccess: {4}
-
delete: olcAccess
olcAccess: {3}
-
delete: olcAccess
olcAccess: {1}
-
delete: olcAccess
olcAccess: {1}
-
delete: olcAccess
olcAccess: {0}
-
# Allow everything in this database to be managed by anyone in the `sysadmins` group.
add: olcAccess
olcAccess: {0}to *
 by group.exact="cn=sysadmins,ou=groups,dc=opensource,dc=osu,dc=edu" manage
 by dn.exact="cn=ldaprepl,ou=manage,dc=opensource,dc=osu,dc=edu" read
 by * break
-
# Allow binding to anything that has a password. Allow itself to change the passwd (and sysadmins as shown above), but nothing by nobody else.
add: olcAccess
olcAccess: {1}to attrs=userPassword
 by self write
 by anonymous auth
 by * none
-
# This one I'm kinda proud of. Every `ou` underneath `ou=applications` is an app that has `cn=admins` and `cn=hosts` set up when everything else is set up for a new app. This allows every entry in `cn=admins` to control everything in the app directory. This should include user accounts who are going to administrate the application, as well as authenticated service accounts that need any more than read access.
add: olcAccess
olcAccess: {2}to dn.regex=".*ou=([^,]+),ou=applications,dc=opensource,dc=osu,dc=edu$"
 by group.expand="cn=admins,ou=$1,ou=applications,dc=opensource,dc=osu,dc=edu" manage
 by users read
 by * none
-
# We want to protect the security of the accounts and things we use to manage the LDAP database. So far we have the rootDN in there, the ldaprepl user (which already has read everywhere), and the password policy configuration. We may need more access for the password policy config, but I'm not sure at this point.
add: olcaccess
olcaccess: {3}to dn.subtree="ou=manage,dc=opensource,dc=osu,dc=edu"
 by * none
-
# All children of `dc=opensource,dc=osu,dc=edu` should be readable by all users if it hasn't matched any of the above rules already, which would be `ou=hosts`, `ou=people`, `ou=groups`, etc. This is the same as `cat`ting `/etc/passwd` and getting the same info there. If this is too wide-open, then we can add more above. But for now, I'd _love_ to call this shit finished, as I've spent >50 hours on LDAP already. Ugh. Worth it tho!
add: olcAccess
olcAccess: {4}to *
 by users read
 by anonymous none

dn: olcDatabase={0}config,cn=config
changetype: modify
# Allow everything in this database to be managed by anyone in the "sysadmins" group.
add: olcAccess
olcAccess: {0}to *
 by group.exact="cn=sysadmins,ou=groups,dc=opensource,dc=osu,dc=edu" manage
 by * break
-
# Allow everything in this database to be managed by anyone in the "sysadmins" group.
add: olcAccess
olcAccess: {1}to *
 by * none

dn: olcDatabase={-1}frontend,cn=config
changetype: modify
# Allow everything in this database to be managed by anyone in the "sysadmins" group.
add: olcAccess
olcAccess: {0}to *
 by group.exact="cn=sysadmins,ou=groups,dc=opensource,dc=osu,dc=edu" manage
 by * break
-
# Disallow everything else, except for the rootdn, since when using the rootdn, all ACL's are skipped.
add: olcAccess
olcAccess: {1}to *
 by * none
```


### Start Service

Make sure firewall is open and restart ldap.

```
# firewall-cmd --permanent --add-service=ldap
# firewall-cmd --permanent --remove-service=dhcpv6-client
# firewall-cmd --reload
# systemctl enable slapd
# systemctl restart slapd
```

## Fedora client server setup

Run the following `ansible-playbook` command with a sysadmin's account:

```
ansible-playbook -ki dnsmastin01fato, --ask-vault-pass ldap_host.yml -u root
SSH password:
Vault password:
Please enter your LDAP password:
```

For a new server, this will:

1. SSH as root, so put in root's SSH password (because the `-k` switch will prompt for it) since this is setting up LDAP in the first place
  - This _can_ be run as another user as long as that user has sudo-to-root priv's (read: oscadmin)
2. Prompt for the vault password, since Vault is needed for this. Any other way to decrypt the vault is acceptable.
3. Run this on a jumphost as a sysadmin.
4. Prompt for the sysadmin's LDAP password to place the server in the database with all its info, etc.

This should be run every time a new server is deployed. Unfortunately, since we are logging in as root and passing the root passwd (unique for every server) we have to do this one server at a time. Not bad for now, but work re-evaluating in the future.

# Clear SSSD's cache

To clear `sssd`'s cache, issue the following command as root:

```bash
sss_cache -E
```

### SSSD troubleshooting

If you get _anything_ about `/var/lib/sss/pipes/private/`, then delete that directory, and recreate it with the owner and group set to `sssd`, and try restarting `sssd`.

Also, check your `ldap_*_search_base` strings. Try something super simple, and get it to work. Work your way back from there.

# References

## General:

https://www.freebsd.org/doc/en_US.ISO8859-1/articles/ldap-auth/index.html
http://www.brennan.id.au/20-Shared_Address_Book_LDAP.html
http://www.zytrax.com/books/ldap/
http://www.openldap.org/doc/admin24/

## OLC Config

http://www.openldap.org/doc/admin24/slapdconf2.html
http://www.zytrax.com/books/ldap/ch6/slapd-config.html

## DIT Structure:

https://wiki.archlinux.org/index.php/LDAP_Hosts
https://www.openldap.org/lists/openldap-technical/201003/msg00039.html
http://www.drdobbs.com/system-inventory-using-ldap/199101881
https://wiki.debian.org/LDAP/PAM
http://www.tldp.org/HOWTO/archived/LDAP-Implementation-HOWTO/pamnss.html
https://thornelabs.net/2013/01/28/linux-restrict-server-login-via-ldap-groups.html
https://docs.oracle.com/cd/E23824_01/html/821-1455/gladg.html

## SSSD

https://wiki.contribs.org/Client_Authentication:Fedora_via_sssd/ldap
https://access.redhat.com/documentation/en-us/red_hat_enterprise_linux/7/html/system-level_authentication_guide/configuring_domains
https://docs.pagure.org/SSSD.sssd/users/troubleshooting.html
https://jhrozek.wordpress.com/2015/03/11/anatomy-of-sssd-user-lookup/

## LDAP commands

https://www.thegeekstuff.com/2015/02/openldap-add-users-groups/

## TLS

http://www.openldap.org/faq/data/cache/185.html

## Replication

https://www.openldap.org/doc/admin24/replication.html
https://www.itzgeek.com/how-tos/linux/configure-openldap-master-slave-replication.html
https://askubuntu.com/questions/360190/how-to-configure-master-slave-ldap-replication
https://www.server-world.info/en/note?os=Fedora_26&p=openldap&f=4
https://docs.fedoraproject.org/f27/system-administrators-guide/servers/Directory_Servers.html

## ACLs

http://www.openldap.org/doc/admin24/access-control.html
http://www.openldap.org/lists/openldap-technical/201306/msg00244.html
https://medium.com/@moep/keeping-your-sanity-while-designing-openldap-acls-9132068ed55c
http://www.openldap.org/faq/data/cache/52.html
http://www.openldap.org/faq/data/cache/1133.html
http://www.openldap.org/faq/data/cache/973.html


## Password Policy

https://www.openldap.org/doc/admin24/security.html
http://www.zytrax.com/books/ldap/ch6/ppolicy.html
https://serverfault.com/questions/847814/openldap-setting-up-olcoverlay-ppolicy
http://www.ryanfrantz.com/posts/openldap-implementing-the-password-policy-overlay/
https://tobru.ch/openldap-password-policy-overlay/
http://tutoriels.meddeb.net/openldap-password-policy-managing-users-accounts/
https://serverfault.com/questions/571928/how-do-you-set-password-hash-for-openldap

## Sudo

https://jhrozek.livejournal.com/2065.html
https://linux.die.net/man/5/sssd-sudo
https://github.com/jtyr/rfc2307bis/ && https://github.com/shoop/openldap-rfc2307bis/
