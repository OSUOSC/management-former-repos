#! /bin/bash

# Author: Brian Swaney
# Description: Generic script to update a Drupal website. Used to 
# minimize downtime and consistently backup site before updating.
# Instructions: Update variables below before each use, run as root.

########################################################################
# This program is free software: you can redistribute it and/or modify #
# it under the terms of the GNU General Public License as published by #
# the Free Software Foundation, either version 3 of the License, or    #
# (at your option) any later version.                                  #
#                                                                      #
# This program is distributed in the hope that it will be useful,      #
# but WITHOUT ANY WARRANTY; without even the implied warranty of       #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        #
# GNU General Public License for more details.                         #
#                                                                      #
# You should have received a copy of the GNU General Public License    #
# along with this program.  If not, see <http://www.gnu.org/licenses/>.#
########################################################################

# Each package that requires an update is directly linked from
# /admin/reports/updates. Right-click the "Download" link and copy the URL.
# Use this to list all packages and themes requiring updates separately,
# using quotation marks and spaces as a delimiter. It is not possible to 
# obtain or parameterize this list through automated means.
download_packages=( "http://ftp.drupal.org/files/projects/captcha-7.x-1.0.tar.gz" "http://ftp.drupal.org/files/projects/mollom-7.x-2.6.tar.gz" "http://ftp.drupal.org/files/projects/scheduler-7.x-1.1.tar.gz" "http://ftp.drupal.org/files/projects/token-7.x-1.5.tar.gz" )
download_themes=(  )
# Set this line to the new Drupal core version.
drupal_path='/var/www/html'
backup_location='/opt/backups'
# Set this to true if updating Drupal core, then set the old and new version accordingly.
update_core=true
new_core="7.23"
old_core="7.20"

# ------------------------------------------
# Nothing below this line should be changed.
# ------------------------------------------
timestamp=$(date +%m-%d-%y_%H:%M:%S)
# Read database settings from settings.php file
settings='sites/default/settings.php'
backup_file="$backup_location/drupal_backup_$timestamp.sql"
echo -e "Backing up database to $backup_file using the\nconfiguration found in $drupal_path/$settings...\nIf you see errors in this step, confirm the \e[1;34mdrupal_path\e[0m value is\nset to the correct location where you have installed Drupal.\e[0m"
db_name=$(grep -A 9 databases $drupal_path/$settings |grep -v \*|grep \'database\'|cut -d \' -f 4)
db_user=$(grep -A 9 databases $drupal_path/$settings |grep -v \*|grep username|cut -d \' -f 4)
db_host=$(grep -A 9 databases $drupal_path/$settings |grep -v \*|grep host|cut -d \' -f 4)
db_pass=$(grep -A 9 databases $drupal_path/$settings |grep -v \*|grep password|cut -d \' -f 4)
# Backup database to backup_file location
mysqldump -u $db_user -h $db_host -p$db_pass $db_name > $backup_file
# Confirm that backup was successful
if [ -f $backup_file ]; then # Backup file exists
    if [ "$(wc -l $backup_file|awk '{print $1}')" -lt 1 ]; then # Backup file empty
        echo -e "\e[1;31mDatabase backup appears to have failed (backup file empty). Aborting...\e[0m"
        exit 1
    elif [ "$(wc -l $backup_file|awk '{print $1}')" -lt 1000 ]; then # Backup file less than 1000 lines (4000+ is typical)
        echo -e "\e[1;31mDatabase backup appears to have failed (backup file unusually small). Aborting...\e[0m"
        exit 1
    else
        echo -e "\e[1;32mDatabase successfully backed up to $backup_file.\e[0m"
    fi
else
    echo -e "\e[1;31mDatabase backup appears to have failed (backup file doesn't exist). Aborting...\e[0m"
    exit 1
fi 


echo "Please set Drupal into maintenance mode. You can do so from here:"
# TODO: Find a way to dynamically determine FQDN from in virtual machine
echo "https://opensource.osu.edu/admin/config/development/maintenance"
read -p "Press [ENTER] to continue."
cd $drupal_path
cd .. # Go to parent folder
if [ "$update_core" == "true" ]; then
	echo "Downloading new version of Drupal core..."
	wget -q http://ftp.drupal.org/files/projects/drupal-$new_core.tar.gz
	tar -xzf drupal-$new_core.tar.gz
	rm drupal-$new_core.tar.gz
	echo "Moving files..."
	rm -Rf drupal-$new_core/sites # Delete default config files
	mv $drupal_path/sites drupal-$new_core/

	# Back up old core
	mv $drupal_path drupal-$old_core
	mv drupal-$new_core $drupal_path

	# Move static files (explained per-line)
	cp drupal-$old_core/google225acc9ff85695bb.html $drupal_path/ # Google verification file for Webmaster Tools (best way to verify without Google Analytics)
	cp drupal-$old_core/broken-helpme.php $drupal_path/ # Fix to ensure emergency "Something is broken and I don't know what to do" file is available when critical services fail
	cp drupal-$old_core/*.html $drupal_path/ # Static HTML files (including SOPA protest page from blackout)
	ln -s /var/www/microwiki $drupal_path/ # Archive of old site pre-dating Drupal (database is set to read-only and password hashes zeroed out because software is NOT maintained)

	# Migrate JQuery libraries if applicable (have caused complications before)
	echo "Moving JQuery libraries to new Drupal installation..."
	if ! [ -d "$drupal_path/sites/all/libraries" ]; then
		mkdir $drupal_path/sites/all/libraries
	fi
	mv $drupal_path/sites/all/modules/jquery_ui/jquery.ui $drupal_path/sites/all/libraries/
fi
cd $drupal_path/sites/all/modules
# Download and extract each individual package from drupal.org, and store the old version in /tmp
# Note: Do NOT include "migrate" module as there is no upgrade path and trying to update will cause recurring database errors that can only be corrected by reverting the database. JQuery_UI is also causing some grief.
echo "Downloading patched modules..."
for package in "${download_packages[@]}"; do
	package_file=`basename $package`
	package_name=`basename $package | sed -re 's/(-[0-9].*)//'`
	echo "Patching $package_name..."
	wget -q $package
	if [ -d "$backup_location/$package_name" ]; then
		rm -Rf $backup_location/$package_name
	fi
	mv $package_name $backup_location/
	tar -xzf $package_file
	rm -f $package_file
done
cd ../themes # Repeat above module download procedure for any listed themes to update
for package in "${download_themes[@]}"; do
	package_file=`basename $package`
	package_name=`basename $package | sed -re 's/(-[0-9].*)//'`
	echo "Patching $package_name..."
	wget -q $package
	if [ -d "$backup_location/$package_name" ]; then
		rm -Rf $backup_location/$package_name
	fi
	mv $package_name $backup_location/
	tar -xzf $package_file
	rm -f $package_file
done
echo "Fixing permissions..."
find $drupal_path -type f -exec chmod 644 {} \;
find $drupal_path -type d -exec chmod 755 {} \;
apache_user=$(ps axho user,comm|grep -E "httpd|apache"|uniq|grep -v "root"|awk 'END {if ($1) print $1}')
chown -R $apache_user:$apache_user $drupal_path/sites/default/files # For servers running as Apache
# chmod -R 777 $drupal_path/sites/default/files # For servers running as nobody
echo "Running CRON..."
wget -O- --no-check-certificate -q http://localhost/cron.php?cron_key=
echo "You may now proceed to the update script at https://opensource.osu.edu/update.php"

