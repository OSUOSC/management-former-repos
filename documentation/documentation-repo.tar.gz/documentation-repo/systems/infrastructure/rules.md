Everyone:

Never EVER unplug the ethernet cable, and if you do, DON'T plug another computer in place of it. This will trip a security mechanism on the CSE network, which will shut off our port. Again, we are trying to avoid additional network outages at all costs.

If you get in your terminal saying "MCSS check failed" please run the command "update". You will have appropriate privileges to run this command as a desktop user.

So long as there is internet, under no circumstances should anyone modify internet settings. If internet is disabled, we may not get it back for a long time, and it is difficult process to restore it. The last outage lasted nearly a year. I'm serious.

Do not leave any unauthorized people in the office unattended. If you have to let someone in, please make sure they leave with you. If they need access, the club president can send a request to add their ID to the door.

Do not share your password with anyone, or log them in under your name. If they are experimenting with Ubuntu, there is a limited guest user account that they can use, and if they are an active club member, they may also soon receive an account. Do not log into this account as your main account. The guest account details are username:opensource and password:Inspiron530

Passwords are required to be strong. Please change your password immediately upon your first login. There should be a script enforcing password rules.


Regular users:

You should have received a properly configured account by the time you are reading this. Please use that username/password on this machine, unless told otherwise. If for some reason your account is not working, there is a paper with a guest account tapped to the wall to the left of the door.

Do not attempt to change your account settings, or circumvent security procedures.

You must use strong passwords for your user name. This should be enforced by the MCSS script running on the machine. Do not attempt to circumvent it, as that is a violation of MCSS policy.


Administrators:

Accounts may be created for OSU students only. For security reasons, please only add active, attending members. Except under extraordinary circumstances, only club officers should have administrative access. All other users should have regular accounts.

When creating an account, the user may decide which user name to use, within reason, but they must have their full name listed to identify themself. Strong passwords must be used, which should be enforced by the MCSS compliance script. The user name "guest" is not allowed.

In the event of web hosting (not currently enabled), which would be on this machine, only active and trusted members should have access to a web space, and only personal, non-business-related pages are allowed. This is for security reasons; if we easily allowed any users to host files, it could compromise the machine and the CSE network, and piss off OSU's security team. We do not want that.

There is an administrative account, csecs, which is used by the CSE helpdesk. Do not modify or delete this account. MCSS regulations require that the CSE department staff have adminitrative access to this machine. Do not uninstall/disable the firewall, or antivirus, and do not make excessive exceptions to the firewall rules. Port 22 (SSH) should be enabled at all times. Additionally, do not remove any of the files in /root/mcss. Violating any of these rules would be a violation of MCSS and can result in disconnection from the CSE network.
