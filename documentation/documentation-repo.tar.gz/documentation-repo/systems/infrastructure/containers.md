---
author: smacz
date: 2018-01-21
service: "Containers"
description: "How to set up and maintain containers in the open source club's network"
type: infrastructure
references:
  - title: "All about LVM"
    link: 'https://www.thegeekstuff.com/2010/08/how-to-create-lvm'
todo:
  - add references
---

# Installation

## Set up LVM

I use XFS for various reasons - namely that it is a ridiculously solid filesystem and it has been battle-tested over many years of use. Feel free to use some other type of filesystem (ext4) if you are so inclined, but make sure to adjust the `/etc/fstab` entry appropriately if you do.

```bash
# mkdir -p /srv/libvirt/filesystems/<new_server>
# lvcreate -n <new_server> -L 10G system
# mkfs.xfs /dev/system/<new_server>
# mount /dev/system/<new_server> /srv/libvirt/filesystems/<new_server>
```

Make sure that once this is complete that you update the `/etc/fstab` with the new mountpoint.

## Install Container OS

```
virt-bootstrap virt-builder://fedora-28 /var/lib/libvirt/virt/filesystems/<new_server>
```

Make sure to grab the root password for the container and put it into keepass for use later on.

## Bind Mounts

Next it is time to set up the bindmounts as explained in [focault.md](./focault.md) and [turing.md](./turing.md) for the data directories of the container. First, create the dataset in `focault`, and then create the mountpoint on `turing`. Mount them as necessary (mysql, files, etc.) with bindmounts inside of the container directory, and verify that their permissions are set accordingly.

## Virt-Manager

After doing the above, it is time to initialize the container using the virt-manager tool. This is easily done with that GUI, otherwise, an entire XML setup will be required. In fact, the GUI setups up the XML file for us, just prompting us for a couple questions.

Please keep in mind that virt-manager is a tool that runs on your own machine that connects remotely to the server over ssh. This is detailed out in [turing.md](./turing.md) in conjunction with setting up the host.

Make sure the connection is to the **[LXC]** setup so the setup is for a container, and not a VM. First off, we're going to choose **[Operating System Container]**, and then select the **[existing OS root directory]**. The **[srv-filesystems]** storage volume (which points at `/srv/libvirt/filesystems`, where the LVMs are mounted) should be set up.

RAM should be set to 256MB at a minimum, and 1 CPU should be just fine, especially since our plan is to split up services to various containers.

After that, the container name should be like `jumphost-01`, with the name the exact same as the hostname.

Make sure that the `Network Selection` is the correct network for the container, which should be the application name itself.

After the setup, the host will initialize the XML file in `/etc/libvirt/lxc` and boot the container.

## Set hostname

The last thing to do is log in with that root password that should be in your keepass if you followed the directions in [Install Container OS](## Install Container OS). The set the hostname with the command below:

```
# hostnamectl set-hostname <fqdn of server>
```

### Ubuntu Networking

Ubuntu won't recognize the ethernet NIC as it's not going to be named the same was as is defaulted to in the config file. Go in and change all references to `ens2` in `/etc/network/interfaces` to `eth0`, or whatever the first part of the interface name is (before the `@` character). After that, restart the daemon `networking`, and it should acquire a DHCP lease from the router/firewall.

## Setup with FreeIPA

FreeIPA does magic with SSSD, kerberos, PAM, etc. that is way too involved to do by hand. Luckily, all of the major distros have an IPA client that sets all of this up for us. Once that's installed, it will give us the command `ipa-client-install` to work with.

```
ipa-client-install --server=freeipa.opensource.osu.edu --domain=opensource.osu.edu -p admin --mkhomedir
```

Look in the keepass file for the admin password. Otherwise, a sysadmin may replace `admin` with their own username.

#### Note that I've only ever tested this with a sysadmin account. General member accounts may not have sufficient privs to register a server.

# Maintenance

## Upgrade Fedora

```
$ sudo dnf --releasever=27 upgrade
```

## Shutdown container

```
# halt
```

## Snapshot Logical Volume

https://www.tecmint.com/take-snapshot-of-logical-volume-and-restore-in-lvm/
