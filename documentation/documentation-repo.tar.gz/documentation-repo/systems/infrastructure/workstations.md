---
author: oscziryak
date: 2018-11-01
service: "Workstations"
discription: "This is the setup of the kanboard servers"
references:
  - title: "Create RAID1 in Linux"
    link: 'https://www.tecmint.com/create-raid1-in-linux/'
todo:
  - FreeIPA auth integration
  - Remote storage on FreeNAS
    - DB server
    - raw file storage
type: infrastructure
servers:
  - fqdn: von-neumann.opensource.osu.edu
    mounts: 
      - name: /dev/md0
        location: /mnt/raid1
  - fqdn: knuth.opensource.osu.edu
firewall: ""
network:
  - name: 'office'
    subnet: 10.0.194.0/24
application: ''
admin_group: ''
svc_accts: ''
---

# Installation

## FreeIPA and LightDM

Once FreeIPA is installed and working on the maching, set up the preferences to allow LDAP users to log in by name:

```bash
# grep -Re '^greeter.*\|^\[Seat.*' /etc/lightdm/lightdm.conf 
[Seat:*]
greeter-hide-users=true
greeter-show-manual-login=true
```

## Backups

Backups will be put on the RAID1 array on `von-neumann` (created as shown in the referenced article). These should have the same directory structure as what is shown in `focault`.

# Maintenance


