---
author: smacz
date: 2018-01-29
service: "Virtual Machines"
description: "How to set up virtual machines on our network"
type: infrastructure
references: ""
todo:
  - Actually write this
---

# NIC

The Device model of the NIC should be `virtio`, otherwise, external hosts (stallman, etc.) won't be able to route to it.

## Fedora
```
# dnf upgrade --refresh
# dnf install dnf-plugin-system-upgrade
# dnf system-upgrade download --refresh --releasever=27
# dnf system-upgrade reboot
```

## FreeBSD

```
# cat << EOF > /etc/rc.conf
ifconfig_DEFAULT="inet 10.0.3.34 netmask 255.255.255.0"
defaultrouter="10.0.3.13"
hostname="ldapmstin01bato.adm.opensource.osu.edu"
sshd_enable="YES"
EOF
# cat << EOF > /etc/resolv.conf
domain adm.opensource.osu.edu
nameserver 10.0.3.33
EOF
# shutdown -r now
# pkg install sudo
# adduser oscadmin -G sudo
# passwd oscadmin
# visudo
   :%s/# %wheel ALL=(ALL) ALL/%wheel ALL=(ALL) ALL/
```

