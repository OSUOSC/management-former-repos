---
author: smacz
date: 2018-01-14
service: "Turing"
description: "This document details how the Fedora virtualization host `turing.opensource.osu.edu` is/was set up"
type: infrastructure
references:
  - title: 'CentOS Forums Reference'
    link: 'https://www.centos.org/forums/viewtopic.php?t=61444'
todo:
  - what has changed since this was written?
type: infrastructure
servers:
  - fqdn: turing.opensource.osu.edu
    services:
      - name: kvm/qemu
firewall: ""
network:
  - name: 'turing'
    subnet: 10.0.35.0/24
application: 'turing'
admin_group: 'turing_admins'
svc_accts:
  - 'oscadmin'
---

# Virtualization

## KVM Setup

In order to set up the KVM host, we have to install the virtualization group and the configure the admin user to be able to administer the configuration.

```
$ sudo dnf group install --with-optional virtualization
$ sudo usermod -a -G kvm,libvirt  <admin_user>
$ sudo cat << EOF > /etc/polkit-1/localauthority/50-local.d/50-libvirt-remote-access.pkla
[libvirt Management Access]
# For allowing access to specific user only:
#Identity=unix-user:<admin_user>
# For allowing access to a group:
Identity=unix-group:libvirt
Action=org.libvirt.unix.manage
ResultAny=yes
ResultInactive=yes
ResultActive=yes
EOF
$ sudo chown root:kvm /dev/kvm
```

Setting the number of file descriptors so that it doesn't hit a max with >5 containers, 'cause those suckers consume files like nothing else!

```
# cat << EOF > /etc/sysctl.d/99-sysctl.conf
fs.file-max = 9999999
fs.inotify.max_queued_events = 99999
fs.inotify.max_user_instances = 99999
fs.inotify.max_user_watches = 999999
```

Then restart the server just to make sure it gets taken.

## Bridging external ethernet to internal virtual bridge

We're going to slave one of our our virtual bridges to an actual ethernet NIC so that our pfSense VM can have access to the outside world.

```
# nmcli dev status
# ip link set enp0s18 up
# ip link set enp0s18 master virbr4
# nmcli dev status
  (should say 'connected' in green)
```

## Bridging virtual guest network to host

First we need to create a new guest interface named 'turing'. If we do it in virt-manager like every other network, we'll have to manually edit the configs in order to add an IP address to the bridge:

```
# virsh net-edit turing
<network>
[...]
  <ip address='10.0.35.2' netmask='255.255.255.0'/>
</network>
```

Then we need to add it to pfSense, and then restart both pfSense and then libvirt.

Then, we need to set the interface's ip address, and set the correct route:

```
ip address add 10.0.35.2/24 dev virbr4
ip route add 10.0.0.0/16 via 10.0.35.1 dev virbr4
```

Since we're setting this as a static IP address, we should put it into the pfSense GUI so that it forwards correctly. **[Services]** -> **[DNS Resolver]** -> **[General Settings]** -> **[Edit Host Override]**

# Port Forwarding to Guest Interface that's NAT'd

Taken from [libvirt.org](https://wiki.libvirt.org/page/Networking#Forwarding_Incoming_Connections)

As `root`:

```bash
git clone https://github.com/saschpe/libvirt-hook-qemu
cd libvirt-hook-qemu
make install
cat << EOF > /etc/libvirt/hooks/hooks.json
{
    "pfSense": {
        "private_ip": "192.168.122.158",
        "port_map": {
            "tcp": [[80, 80],
                    [2222, 2222]]
                    [1025, 1025]]
                    [443, 443]]
        }
    }
}
EOF
systemctl restart libvirtd
```

This script takes the config in `hooks.json` and looks for the name that is specified as the top-level. This is the name that is known to libvirt. The private IP is the IP address that is routable from the host. Each list of ports is the source (host), and destination (guest) respectively. You can add multiple hosts to this config, and their outgoing traffic gets NAT'd just like normal.

Check that this is set up with:

```
# iptables -t nat -S | grep 192
```

If it's not working, try shutting off, and then turning on the VM it's forwarding to. Do not simply reboot the virtual server, but actually shut it down so that `libvirtd` (on the host) knows it's shut down so that it can run the post, and then pre hooks that are triggered here.

# NFS Mounts

We are using FreeNAS on `focault` to house our data. We are not necessarily hosting our VMs/Container directories on there. There is no reason to since we have a RAID'd 1TB local storage on which to host them. However, for file storage (nextcloud uploads) or databases (kanboard's mysql database), this is a great solution! It allows us a data warehouse that we can take care of independently from the systems that serve it.

## Interfaces

`turing` recently got a dual-interface NIC that is going to be connected with two crossover cables to `focault`. One of these interfaces is functioning as a direct connection between the two operating systems so that shares from `focault` can be mounted on `turing` with the minimal amount of overhead.

These interfaces live in `172.16.1.0/24` - namely:

`focault`: 172.16.1.2
`turing`: 172.16.1.3

## Mount Points

See [focault.md](./focault.md) for the details of the export paths. 

### Containers

Mounting it for use in a container is a dual-purpose affair. First, the NFS share is mounted on `turing`, and then that mountpoint is bind-mounted inside the container's filesystem. We keep all of our NFS mounts under `/mnt/data-mounts/<server name>-<directory name>/`. For instance for a typical mysql mount:

```
# mount 172.16.1.2:/mnt/osc-volume/data-mounts/<server name>-mysql/ /mnt/data-mounts/<server name>-mysql/
# mount --bind /mnt/data-mounts/<server name>-mysql/ /srv/libvirt/filesystems/<server name>/var/lib/mysql
```

Then, the following lines go in `/etc/fstab`:

```
172.16.1.2:/mnt/osc-volume/data-mounts/<server name>-mysql /mnt/data-mounts/<server name>-mysql/ nfs defaults 0 0
/mnt/data-mounts/<server name>-mysql/ /srv/libvirt/filesystems/<server name>/var/lib/mysql none defaults,bind 0 0
```

After you do this, it's best to restart the guest OS just to have it pick up any relevant changes.

# Network dump

```
enp0s18 -> master -> virbr1
ip address add 10.0.35.2/24 dev virbr4
ip route add 10.0.0.0/16 via 10.0.35.1 dev virbr4
```

