---
author: smacz
date: 2018-09-28
service: "Focault"
description: "Humans generate an ever-increasing amount of data. This is how the OSC stores theirs; on a server for starters."
type: infrastructure
references:
  - title: 'A Complete Guide to FreeNAS Hardware Design, Part III: Pools, Performance, and Cache'
    link: 'http://www.freenas.org/blog/a-complete-guide-to-freenas-hardware-design-part-iii-pools-performance-and-cache/'
  - title: 'FreeNAS 11 User Guide'
    link 'https://doc.freenas.org/11/freenas.html'
  - title: 'The 3-2-1 Backup Strategy'
    link: 'https://www.backblaze.com/blog/the-3-2-1-backup-strategy/'
  - title: 'FreeNAS 11.1 User Guide: 6.4 Rsync Tasks'
    link: 'http://doc.freenas.org/11/tasks.html#rsync-tasks'
  - title: 'Backup Config File Every Night Automatically'
    link: 'https://forums.freenas.org/index.php?threads/backup-config-file-every-night-automatically.8237/'
todo:
  - add how to upgrade
  - add auto-upgrade
  - infrastructure filesystem backup specifics
servers:
  - fqdn: focault.opensource.osu.edu
    services:
      - name: nfs
      - name: httpd
        port: 80
network:
  - name: 'focault'
    subnet: 10.0.40.0/24
  - name: 'turing'
    subnet: 172.16.1.0/24
application: 'focault'
admin_group: 'focault_admins'
srv_accts:
  - 'mysql'
---

# Setup

## ZFS Pool Configuration

> The need for IOPs becomes important when providing storage to things like database servers or virtualization platforms. These use cases rarely utilize sequential transfers. In these scenarios, you’ll find larger numbers of mirrors or very small RAIDZ groups are appropriate choices. 
>
> For best performance on random IOPS, use a small number of disks in each RAID-Z group. E.g, 3-wide RAIDZ1, 6-wide RAIDZ2, or 9-wide RAIDZ3 (all of which use one-third of total storage for parity, in the ideal case of using large blocks). This is because RAID-Z spreads each logical block across all the devices (similar to RAID-3, in contrast with RAID-4/5/6). For even better performance, consider using mirroring.
>
> [...] a pool of mirror vdevs is by far the best performing ZFS topology.
>
> [You Should Use Mirrored vdevs Not RaidZ](http://jrs-s.net/2015/02/06/zfs-you-should-use-mirror-vdevs-not-raidz/)

**DESPITE** all of that, we're going to try running this in RAIDZ2, since it is more redundant. I honestly doubt that you fucks will actually take care of this network, and that this documentation is mostly for me to apply to my own future endevours despite having a homelab of my own that I play around in, but it's easier to have a drive array that is _globally_ resiliant to a grand total of 2 disks (and that's _any_ two disks) failing rather than an unfortunate occurrance of two disks in the same vdev.

## Volume

```yaml
- Volume Name: osc-volume
  RAID: RAID Z2
```

# Users

There is the necessity to map users on `turing` in the containers to users on `focault`. To do this, we have to make sure we have the correct UID number owning the shares. So we create the users that the files are owned as. For instance (on `turing`):

```
# [root@turing ~]# ls -ln /srv/libvirt/filesystems/kanboard-ui/var/www/html/kanboard/ | grep data
drwxrwxr-x.  3 48 48    71 Sep 17 23:07 data
```

So our dataset that is going to be exported via NFS needs to be owned by user with the UID number of 48. So first, we look and see if there is an existing user with that UID number:

**[Account]** -> **[Users]** -> **[View Users]**

Before creating it, there was no user with the UID number of 48. 

#### NOTE: Primary groups that are automatically created have a randomly assigned GID number to them. We don't want that - we want a specific number. Therefore the primary group for the user should be created first with the specified GID number.

First we create the primary group for our new user:

**[Account]** -> **[Groups]** -> **[Add Group]**

```yaml
- Group ID: 48
  Group Name: apache
```

So now we create the new user:

**[Account]** -> **[Users]** -> **[Add Users]**

```yaml
- User ID: 48
  Username: apache
  Create a new primary group for the user: [ ]
  Primary Group: apache
  Shell: nologin
  Full Name: Apache
  Password: `<keepass>`
  Password confirmation: `<keepass>`
```

## Groups

To add a user to a group in FreeNAS, we have to use the `pw` command like so:

```
oscadmin@focault #: sudo pw group mod apache -m rsyncbackup
```

This modifies the group `apache` to include the `rsyncbackup` user.

## FreeIPA Authentication

https://redmine.ixsystems.com/issues/27638

# Services

## Hosting services on the FreeNAS server itself

We don't yet.

### Accessing ZFS datasets from jails

https://forums.freebsd.org/threads/44153/

#### Is running an NFS server in a Jail working yet?

## NFS Homedirs

We will be using a new dataset.

```yaml
- name: home_directories
  mountpoint: /mnt/osc-volume/home_directories
  size: 1024 GiB
```

Then we share that dataset using NFS.

```yaml
- share: UNIX (NFS)
  path: /mnt/osc-volume/home_directories
  comment: NFS home directories
  authorized_networks:
    - 10.0.3.0/24
    - 10.0.2.0/24
  maproot_user: root
  maproot_group: wheel
```

## MySQL Data Mounts

### Create the Dataset

**[Storage]** -> **[Volumes]** -> **[/mnt/osc-volume]** -> **[Create Dataset]**

```yaml
- Dataset Name: `<server name>`
  Share type: Unix
```

**[_server name_]** -> **[Create Dataset]**

```yaml
- Dataset Name: mysql
  Share type: Unix
```

**[Change Permissions]**

```yaml
- Owner (user): mysql
  Owner (group): mysql
  Mode: `drwxr-xr-x`
  Permission Type: [X] Unix
  Set permission recursively: [X]
```

#### NOTE: If you need to copy data onto the share before bind-mounting it, set the permissions to drwxrwxrwx recursively, copy the data over, and set it back to drwxr-xr-x recursively.

### Create the Share

**[Sharing]** -> **[Unix (NFS) Shares]** -> **[Add Unix (NFS) Share]**

```yaml
- Path: `/mnt/osc-volume/data-mounts/<server name>-mysql`
```

#### See [turing.md](./turing.md) for how to mount it

## Backups

If we consider a [3-2-1 backup solution](https://www.backblaze.com/blog/the-3-2-1-backup-strategy/), we can consider that only some of the data in `focault` can be considered a backup. Only the data that is a second copy (of the data that we are _using_) that is on `focault` can be considered a backup.

### Data

The data that lives on `focault` as a primary datastore (database dirs, raw file stores), **cannot** be considered as backups. They must be considered as primaries, and as such, must be backed up somewhere else on the network "on a different medium/device" (see [stallman.md](./workstations.md)).

```
rsyncbackup@focault #: rsync -ave ssh /mnt/osc-volume/data-mounts oscadmin@von-neumann:/mnt/raid1/
```

#### NOTE: The local dir doesn't have a slash after it, meaning that the directory specified (`data-mounts`) is going to be _created_ in the `/mnt/raid1` directory on von-neumann. This leaves room for alternative directories directly on the RAID array without interfering with our data mountpoint backups.

Since this path cannot be sync'd via the GUI (and therefore may not be any other built-in scripts) since it resides outside of the volume mount point, it's probably going to be easier to create a dataset within that volume and set up a manual cron job that does the work of copying it there for us, so we can back it up.

```
rsyncbackup@focault $: crontab -e
50      02      */2     *       *       rsyncbackup     PATH="/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:/root/bin" /usr/bin/lockf -s -t 0 -k "/mnt/osc-volume/data" sudo /usr/local/bin/rsync -r -t -z -a -p --delay-updates -x --rsync-path="sudo /usr/local/bin/rsync" --sparse --exclude=*lastlog "/data/" "/mnt/osc-volume/data" 2>&1 |/usr/bin/logger -t rsync
```

### VMs/Containers

For this iteration of the network (post-idle2) we use the infrastructure host `turing` to host all our VMs and Containers. See [turing.md](./turing.md) for a discussion of the setup. However, the filesystems backing the VMs and Containers OSes need to be backed up somewhere. `focault` provides a perfect place to back those up, as it directly connected to the host OS.

Since the entirety of all of the container's OSes are contained within LVMs, we are able to back up the filesystems contained within the LVMs. Why not create a backup using snapshots of the LVMs you ask? Well, [TecMint](https://www.tecmint.com/take-snapshot-of-logical-volume-and-restore-in-lvm/) has the most succinct (albiet also the most gramatically incorrect) answer I've stumbled upon:

> Snapshots can’t be use for backup option. Backups are Primary Copy of some data’s, so we cant use snapshot as a backup option.

In essence, a LVM snapshot is a local copy (snapshot) of a filesystem. On top of that is written the delta of any changes. However, this is both space-inefficient, as well as I/O-intensive, and therefore not right for a server backup. It would be more efficient to sent a diff of the changes to the filesystem of a given server to the backup medium on a regular, rotating basis.

The word **rotating** there is important. For this, we are going to use a logrithmic generational backup. That's fancy shit for saying three backups for one filesystem - a _really_ old one, a stable one, and a recent one. These are typically named (in due fashion) "Grandfather", "Father", and "Son". For example, the "Grandfather" backup is at least six months old, and at most 12 months old. Similarly, the "Father" backup is at least two weeks old, and at most 6 months old. Following with the pattern, the "Son" backup is at least 1 hour old, and at most two weeks old. This gives us the capacity - at any given time - to restore a backup that can be at least 1 hour old, and at most 12 months old. The **guarantee** however, is a restoration that is between two weeks and 6 months old.

This is acceptable in our case as the backups that we are talking about here are **VMs/Containers'** operating systems, and not database entries. If this ever becomes too long or too short a time, the backup occurrances can be edited. The below shows how we cherry-pick the filesystems that are necessary to backup to ensure that we have the correct subset that contain the OSes of the Containers and the VMs.

```
rsync -avzxe ssh --sparse rsyncbackup@172.16.1.3:/srv/libvirt/filesystems/* /mnt/osc-volume/container-filesystems
for i in ' ' var/ home/; do rsync -avzxe ssh --rsync-path="sudo /usr/bin/rsync" --sparse --exclude=*lastlog rsyncbackup@172.16.1.3:/${i} /mnt/osc-volume/turing/${i}; done
```

### Infrastructure

The server `turing` can be considered an "infrastructure" backup, as it is the bare-metal OS that hosts all our our networked infrastructure and servers. Similarly, the workstation `stallman` can _also_ be considered as an "infrastructure" backup, as it is a base-metal OS as well. We may very well consider that these two hosts have other functionalities (turing as a VM/Container host, and Stallman as a backup target for data where `focault` is the primary storage thereof) yet at the same time view them as strictly routine OS backups.

Both of these servers use RAID arrays for their OSes. Therefore the likelyhood of us having to use the backups to restore the OS are slim-to-none. However, "RAID does not a backup make!" Therefore, we should follow the 3-2-1 solution outlined above. This involves creating a secondary, LAN-local, not-in-use copy of the OS. For `stallman` and `turing`, it makes sense to store this backup on `focault`, as it has access to both of these servers over the network. 
The below should eventually show which filesystems we choose to backup as we don't want to replicate any filesystems that are already being backed up as a result of VM or Container backups:

```
# rsync -avzxe ssh --rsync-path="sudo /usr/bin/rsync" --sparse --exclude=*lastlog oscadmin@von-neumann:/ /mnt/osc-volume/von-neumann/
# rsync -avzxe ssh --rsync-path="sudo /usr/bin/rsync" --sparse --exclude=*lastlog oscadmin@knuth:/ /mnt/osc-volume/knuth/
```

#### NOTE: The `-x` is to avoid crossing into other filesystems, like the ones that are mounted for backups. If other filesystems are added, make sure to add _another_ rsync job to back these up.

We need to back up focault itself.

```
rsyncbackup@focault #: rsync -ave ssh /data/ oscadmin@von-neumann:/mnt/raid1/focault/
```

This backs up the configuration of the server. There is a button under **[General]** -> **[General]** -> **[Upload Config]** that will let you restore the setup of the system at the point of the backup of that `.db` file.

### Rsync Jobs

So combining all these means that we have a couple jobs that we need to schedule, namely backing up:

- Data mountpoints
- VM/Container OSes
- Infrastructure
- Office Workstations

#### NOTE: The reason I separate Infrastructure and Office Workstations is two-fold. Primarily because they serve two purposes - despite the fact that `von-neumann` is treated as an on-site backup for the data mountpoints - namely the server infrastructure and the administrative workstations. Secondarily because they are on individual networks - `turing` is on `Turing`, `focault` is on `Focault`, and the rest are on `Office`.

**First of all** we have to ensure that the `rsyncbackup` user has access to read all of these directories. We don't necessarily want to add unnecessary read permissions, so it's prudent to (if at all possible) add the `rsyncbackup` user to the groups that own the filesystem in order in order to allow them to gain read permissions if nothing else. That is typically local to `focault` in the case of many of the backups.

Next, we have to ensure that the `rsyncbackup` user can login and run rsync as sudo on all the servers necessary. This works out to be all of the physical servers. So what we want to do is make sure our physical servers are using FreeIPA for authentication, and set up the sudo rules and public (authorized) key in FreeIPA so it gets standardized around the network.

In order to create the jobs listed above in the GUI, I created the following under **[Tasks]** -> **[Rsync Tasks]** for `von-neumann`:

```yaml
- Path: /mnt/osc-volume/von-neumann
  User: rsyncbackup
  Remote Host: von-neumann.opensource.osu.edu
  Remote SSH Port: 22
  Rsync mode: Rsync over SSH
  Remote Path: /
  Validate Remote Path: [X]
  Direction: Pull
  Short description: Von-Neumann - Root
  Minute:
    Each selected minute: 00
  Hour:
    Each selected hour: 03
  Day of month:
    Every N day of month: 2
  Month: [X] (all)
  Day of week: [X] (all)
  Recursive: [X]
  Times: [X]
  Compress: [X]
  Archive: [X]
  Delete: [ ]
  Quiet: [ ]
  Preserve permissions: [X]
  Preserve extended attributes: [ ]
  Delay Updates: [X]
  Extra options: -x --rsync-path="sudo /usr/bin/rsync" --sparse --exclude=*lastlog
  Enabled: [X]
```

This will be the same for the rest of the servers except where follows:

```yaml
- Path: /mnt/osc-volume/container-filesystems
  Remote Host: 172.16.1.3
  Remote Path: /srv/libvirt/filesystems/
  Short description: Container Filesystems
  Minute:
    Each selected minute: 05
- Path: /mnt/osc-volume/turing/
  Remote Host: 172.16.1.3
  Short description: Turing - Root
  Minute:
    Each selected minute: 10
- Path: /mnt/osc-volume/turing/home
  Remote Host: 172.16.1.3
  Remote Path: /home
  Short description: Turing - Home
  Minute:
    Each selected minute: 15
- Path: /mnt/osc-volume/turing/var
  Remote Host: 172.16.1.3
  Remote Path: /var
  Short description: Turing - Var
  Minute:
    Each selected minute: 20
- Path: /mnt/osc-volume/data
  Remote Host: von-neumann.opensource.osu.edu
  Remote Path: /mnt/raid1/focault/data
  Direction: Push
  Short description: Focault - Data
  Minute:
    Each selected minute: 25
- Path: /mnt/osc-volume/data-mounts
  Remote Host: von-neumann.opensource.osu.edu
  Remote Path: /mnt/raid1/data-mounts
  Direction: Push
  Short description: Focault - Data Mounts
  Minute:
    Each selected minute: 30
- Path: /mnt/osc-volume/knuth
  Remote Host: knuth.opensource.osu.edu
  Short description: Knuth - Root
  Minute:
    Each selected minute: 35
```

# Upgrading

The upgrade process has started now that we've got this server set up with an Internet connection. It's fairly straightforward. First navigate to **[System]** -> **[Update]**, select **[Check Now]**, and agree to reboot once the updates are applied.

There have been several scenarios where the server was not rebooted after applying the patches. This is an easy fix, and can be remedied by simply rebooting the server, either through the GUI or the CLI. Either way works, and it should come back up just fine. There should be no need to mess with mounts or anything else. Just make sure it's done during the off-hours so that nobody is using it when it goes down.
>>>>>>> 99776499348bcf7a588f9c784079e8d63f7883c0
