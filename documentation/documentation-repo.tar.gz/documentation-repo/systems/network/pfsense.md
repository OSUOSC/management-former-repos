---
author: smacz
date: 2018-08-01
service: "pfSense"
description: "Since our pfSense VM is externally exposed and handles the entirety of the network, this is a description of the setup of that server, made to be as future-proof as possible."
references:
  - title: 'How can I integrate FreeIPA with pfSense for authentication'
    link: 'https://ask.fedoraproject.org/en/question/63089/how-can-i-integrate-freeipa-with-pfsense-for-authentication/'
todo:
  - ntp
type: network
servers:
  - fqdn: pfsense.opensource.osu.edu
---

# `pfsense.opensource.osu.edu`

We have one pfSense firewall/router that is exposed to the WAN. This server handles a _lot_, which will be detailed out below. As far as resources, this server should recieve as much as possible. Currently that is `2048`GB of RAM and 2 CPU cores. There could be several bottlenecks here, but I don't forsee those settings being an issue anytime soon.

Also note that the VM does not like being forced off. It is best to login to the console and choose 5 or 6. Choose 5 if you just need the VM to pick up changes, but 6 (halt system) if you have some changes at the libvirt level. Otherwise, a simple reboot at the VM level will not trigger libvirt's "When guest is next shutdown" changes.

## Access

We want to limit the access to the WebGUI of the router. We do this by not exposing the port to the outside world, but by only providing routes to connections that originate from either on the host ([turing](../infrastructure/turing.md)) or from the [jumphost](../applications/jumphost.md) network.

For now, we have to set up a proxy so that a browser (Firefox in this case) can be set up to access pfSense by appearing to have its connection originate from one of those two locations. This is done by setting up a SOCKs proxy to them. Proxying through [turing](../infrastructure/turing.md) is probably the easiest as long as we know what the password for the oscadmin user is, since this host does not use LDAP authentication.

```
$ ssh -CND 8081 oscadmin@opensource.osu.edu
```

The `8081` number is the port on our local machine where we are opening up the SOCKs proxy.

Otherwise, we can use the jumphost, as we allow servers in that subnet to connect to the WebGUI of the router; no other subnet is allowed to however.

```
$ ssh -CND 8082 <user>@opensource.osu.edu -p 2222
```

I changed the port just in case you wanted to have both open at the same time.

Now we need to set up Firefox to use that SOCKs proxy so that we can access our internal network and router/firewalls. 

First navigate to `about:preferences`, and navigate to **[General]** -> **[Network Proxy]** -> **[Settings]**. Select the radio button for **[Manual proxy configuration]**, and change the value for **[SOCKS Host]** to `localhost` and the port to `8081`. Select the **[SOCKS v5]** and **[Proxy DNS when using SOCKS v5]** radio buttons. Click **[OK]**, and try to access the router. As a side note, this will also work with any other web configuration that is only accessible from the internal network (e.g. FreeIPA).

### SSH

We also want to set up SSH on a non-standard port for ETS on pfSense. Follow the instructions on [the official wiki page](https://doc.pfsense.org/index.php/HOWTO_enable_SSH_access) to do so.

The port will be 10022, and will need to be added to the general firewall rules for the WAN.

### Sudo

ETS needs access to this router. This means that we should install pfSense sudo package: **[System]** -> **[Package Manager]** -> **[Package Installer]** -> **[sudo]**.

Then we have to give the `csecs` account sudo access for all commands. The configuration setup can be found on [the official wiki page](https://doc.pfsense.org/index.php/Sudo_Package). We will give **[User]**: `csecs` access to **[Run As]**: **[User]**: `ALL Users`, with the **[Command List]**: `ALL`. Obviously, this is basically all access everywhere. Keep it in mind that they have root in our router now.

### WebGUI

The WebGUI should have a separate port to connect on, since the Reverse Proxy on the DMZ router will be used for all incoming connections on the standard web ports. We'll put this on port `9443`. It's not original, but it's not hard to remember either. This can be reached in firefox at the following address - assuming that a SOCKs proxy has already been set up:

```
https://10.0.32.1:9443
```

### Password Protect Console

Anyone who is able to access the console of the virtual machine has the ability to log in as root. As that is _never_ ideal, we want to password-protect the console. This is simply a checkbox under **[System]** -> **[Advanced]** -> **[Console Options]** -> **[Console menu]**: **[X] Password protect the console menu**. And don't forget to **[Save]**.

### FreeIPA Integration

We want to give admins the ability to log in with their own credentials in addition to the local authentication that is used to administer the firewall right out of the gate.

1. Add a new user for pfsense to bind as. (See [freeipa.md](../applications/freeipa.md))
2. Add the [IPA CA certificate](https://freeipa.opensource.osu.edu/ipa/ui/#/e/cert/details/1/cacn=ipa) to **[System]** -> **[Cert Manager]**.

```yaml
Descriptive Name: FreeIPA
Method: Import an Existing Certificate Authority
Certificate data: _paste 'Certificate' from FreeIPA webpage_
Serial for next certificate: 1
```

#### Note that you have to prepend `-----BEGIN CERTIFICATE-----` and append `-----END CERTIFICATE-----` to the raw certificate data for #1.

3. Add the IPA server under **[System]** -> **[User Manager]** -> **[Authentication Servers]** -> **[Add]**:

```yaml
Descriptive Name: FreeIPA
Type: LDAP
Hostname or IP address: freeipa.opensource.osu.edu
Transport: TCP - STARTTLS
Peer Certificate Authority: FreeIPA
Search scope:
  Level: Entire Subtree
  Base DN: dc=opensource,dc=osu,dc=edu
Authentication containers: cn=accounts
Extended Query: [X]
Query: &(memberof=cn=sysadmins,cn=groups,cn=accounts,dc=opensource,dc=osu,dc=edu)
Bind anonymous: [ ]
Bind credentials:
  User DN: uid=pfsensebind,cn=users,cn=accounts,dc=opensource,dc=osu,dc=edu
  Password: <password>
User naming attribute: uid
Group member attribute: memberOf
```

#### Before continuing with #4, test with **[Diagnostics]** -> **[Authentication]**.

4. Change the default authentication to FreeIPA with **[System]** -> **[User Manager]** -> **[Users]** -> **[Settings]**

```yaml
Authentication Server: FreeIPA
```

#### Note that this will still allow authentication of local users like `admin` and `csecs`.

## Adding Interfaces

Whenever a service is added that requires a separate network, an interface needs to be added to the pfSense server. There are a couple boilerplate things to set up each time, and it'll be a disruptive change, so try to do this in the off-hours.

### Virt-manager

Create the new virtual network:

**[QEMU/KVM: opensource.osu.edu]** -> **[Edit]** -> **[Connection Details]**

**[Virtual Networks]** -> **[+]** -> **[Network Name]**: `<new network>` ->_Uncheck "Enable IPv4 network address space definition"_ -> _Uncheck "Enable IPv6 network address space definition"_ -> **[X] Isolated virtual network**

Add a new interface to the pfSense VM:

**[pfSense]** -> **[Open]**

**[VM Details]** -> **[Add Hardware]**

**[Network]**:
  Network source: `<new network>`
  MAC address: **[X]** _The default address should be fine_
  Device model: **[virtio]**

Then go in and shutdown the pfSense VM so that the changes are noticed by libvirt on the host, and start 'er back up.

### WebGUI

Now we have to add the new interface in the administration interface. So log into the WebGUI and go to **[Interfaces]** -> **[Assignments]**. There should now be a new MAC address that is available to that gives you an **[Add]** option. Then, edit it by clicking on, and changing the newly-created `Opt[#]` name. We have to add it and go in and change a couple things. On that interface's page:

Enable: **[X]**
Description: `BLAH`
IPv4 Configuration Type: `Static IPv4`

IPv4 Address: `10.0.XXX.1` `/24`

Block bogon networks: **[X]**

Next we go to set up the DHCP server on that interface:

**[Services]** -> **[DHCP Server]** -> **[BLAH]**

Enable: **[X] Enable DHCP server on BLAH interface**
Range:
  From: `10.0.XXX.2`
  To: `10.0.XXX.254`

**[Save]**

Last, we have to go add that interface to all of the floating firewall rules:

_For rule in_ **[Firewall]** _->_ **[Rules]** _->_ **[Floating]** _:_ **[Edit]** _->_ **[Interface]** _-> CTRL+Click_ **[BLAH]**.

Then you should be good, unless I've forgotten something.


# DNS Resolver

PfSense is our internal DNS server as well, since by doing so, we're able to enter the DHCP leases as DNS entries with its built-in integration.

## Workflow

- Start DNS Resolver service
- Register DHCP Lease
- Be able to query the DNS Resolver with the new DHCP hostname and/or FQDN

## Setup

**[Services]** -> **[DNS Resolver]** -> **[General Settings]**

Enable: **[X] Enable DNS resolver**
Network Interfaces: `All`
Outgoing Network Interfaces: `All`
DNSSEC: **[X] Enable DNSSEC Support**
DNS Query Forwarding: **[ ] Enable Forwarding Mode**
DHCP Registration: **[X] Register DHCP leases in the DNS Resolver**

**[Save]**


# Reverse Proxy

PfSense also acts as a reverse proxy for incoming connections. This is set up through pfSense.

## Workflow

- Incoming web traffic is forwarded correctly based on subdirectory.

### Web Services

- General Website
- Nextcloud

### Security

- Redirects HTTP to HTTPS

## Setup

### Package Install

Go to **[System]** -> **[Package Manager]** -> **[Available Packages]** and install `squid`.

### System Tunables Setup

**[System]** -> **[Advanced]** -> **[System Tunables]**

Add: 

- Tunable: `net.inet.ip.portrange.reservedhigh`
  Value: `0`
  Description: 'Allow Squid Reverse Proxy to bind to Default Ports'

**[Apply Changes]**

## Reverse Proxy Setup

**[Services]** -> **[Squid Reverse Proxy]**

### General

- Interface: `WAN`
- External FQDN: `opensource.osu.edu`
- Reset TCP Connections on Unauthorized Requests: **[X]**

- Enable HTTP Reverse Proxy: **[X]**
- Reverse HTTP Port: `80`

- Eanble HTTPS Reverse Proxy: **[X]**
- Reverse HTTPS Port: `443`
- Reverse SSL Certificate: `osc_production`
- Ignore Internal Certificate Validation: **[X]**

### Web Servers

- Alias: `Website`
  IP: `10.0.64.2`
  Port: `443`
  Protocol: `HTTPS`
- Alias: `Nextcloud`
  IP: `10.0.70.3`
  Port: `443`
  Protocol: `HTTPS`

#### NOTE: Make sure the 'Status' of these web servers is `on`!!!

### Mappings

- Group Name: `Website`
  Enable This URI: **[X]**
  Peers: `Website`
  URI:
  - `^https://www.opensource.osu.edu/((?!nextcloud).)*$`
  - `^https://opensource.osu.edu/((?!nextcloud).)*$`
  - `^https://www.opensource.cse.ohio-state.edu/((?!nextcloud).)*$`
  - `^https://opensource.cse.ohio-state.edu/((?!nextcloud).)*$`
- Group Name: `Nextcloud`
  Enable This URI: **[X]**
  Peers: `Nextcloud`
  URI:
  - `^https://www.opensource.osu.edu/nextcloud.*$`
  - `^https://opensource.osu.edu/nextcloud.*$`
  - `^https://www.opensource.cse.ohio-state.edu/nextcloud.*$`
  - `^https://opensource.cse.ohio-state.edu/nextcloud.*$`

### Redirects

- Redirect Name: `HTTPtoHTTPS`
  Enable This Redirect: **[X]**
  Redirect Protocol: `HTTP`
  Redirect Domains:
  - `opensource.osu.edu`
  - `www.opensource.osu.edu`
  Path Regex: `^/$`
  URL to Redirect To: `https://opensource.osu.edu`

## Squid Proxy Settings

**[Services]** -> **[Squid Proxy Server]**

### General

- Enable Squid Proxy: **[X]**
- Proxy Interfaces: `WAN`

### Local Cache

**[Save]**

#### NOTE: The defaults are all correct, but the setup of the service requires you to hit **[SAVE]** just to confirm it for some idiotic reason.

## Restart Service

Like any other pfSense service, just click the circular arrow button at the top left of any of the pages dealing with the reverse proxy to restart the service. Use this liberally as you never know what change requires a restart in order to take effect.


# Acme Certificates Let's Encrypt Auto-Renew

See [`lets_encrypt.md`](../applications/lets_encrypt.md).

## Integration with Reverse Proxy

The Reverse Proxy service will just use the certificate instead of the full chain, which causes [OSC's Qualys SSL Labs](https://www.ssllabs.com/ssltest/analyze.html?d=opensource.osu.edu) grade to be capped at a 'B'. This is fixed by getting the intermediate CA from out of the full chain provided by the Acme plugin, and putting it into the Reverse Proxy.

### Download Fullchain File

Alongside of the cert, the Acme plugin provides the full chain including the intermediate CA cert. This is the cert we need. This can be either cat'ted out on the command line, or dowloaded from the WebGUI, either way is fine.

I prefer to just download the file from the WebGUI, and going to **[Diagnostics]** -> **[Command Prompt]** -> **[Download File]** and putting in `/cf/conf/acme/osc_production.fullchain` gets us the full chain.

### Entering into "Intermediate CA"

The full chain contains our certificate, as well as the intermediate (Let's Encrypt Authority X3) cert. The thing that SSL Labs was complaining about was that it had to go out to Let's Encrypt and get their intermediate cert separately from our server. So, let's provide it to them!

Copy the second cert that is in that file (Including the `BEGIN/END CERTIFICATE` lines), and paste that into **[Services]** -> **[Squid Reverse Proxy]** -> **[General]** -> **[Intermediate CA Certificate]**. This cert is valid until 2021, which is two years from the date that I am writing this, so it should rarely be changed. This also may be irrelevant by 2021 as Let's Encrypt should have a trusted CA cert at that point, but I'm not sure. Either way, this allows browsers to get the intermediate certs directly from their connection to our side, and it makes Qualys SSL Labs happy.

# References
