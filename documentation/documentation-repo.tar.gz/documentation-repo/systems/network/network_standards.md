---
author: smacz
date: 2018-01-14
service: "Network Standards"
description: "This document describes the details and standards of our networking practices."
references: ""
todo: ""
type: network
---


# Networking

## Subnets

For each IP address, the third octet can indicate what type of services a given subnet provides.

- `10.0.0.0/19` (a.k.a. `0-31`) - Network Appliances (Switches, Routers, Firewalls, etc.)
- `10.0.32.0/19` (a.k.a. `32-63`) - Infastructure (LDAP, Logging, IDS/IPS, etc.)
- `10.0.64.0/18` & `10.0.128.0/18` (a.k.a. `64-191`) - Services (Application Services)
- `10.0.254.0/19` (a.k.a. `192-255`) - Special/Reserved (Jumphost, admin boxes)

## Router Addressing

The router interface addresses always have `1` as the last octect in the IP address. For instance, the IP address of pfsense's jumphost interface is `10.0.192.1`. This makes it easy to debug routing issues if we know where the default gateway should always be.


# Naming Scheme

## Server Names

The hostnames of the servers is not arbitrary - each section of the hostname means something. However, typically there will only be two sections to the hostname. The first part is the application that it's serving (jumphost, nextcloud, etc.). Then there is a dash `-` and an indicator of which part of the service that server is responsible for.

For instance, if the server is the UI server for nextcloud (the one with the PHP code and that is serving apache), then the hostname would be `nextcloud-ui`. Similarly, if you need to spin up a separate jumphost on the network, you can use the name `jumphost-03`. Please note that the indicator is named **as-is appropriate** for the service. If it doesn't make sense to have a `ui` and `db` server for jumphosts, then don't name them that! Name them something that makes sense and is easily recognizable.

Also please note that the secondary indicator is not needed for services with only one server. For instance, the `freeipa` server is named like that because that one server is running everything for that service. There is no separate `db` server or anything else, therefore it is entirely appropriate to name that server `freeipa`.
