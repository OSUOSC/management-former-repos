---
author: smacz
date: 2018-01-14
service: "Switches"
references:
todo: 
  - document IP addr and how to get there
  - get there
type: network
servers:
  - fqdn: dlink1.opensource.osu.edu
    ipv4: 10.0.194.2
  - fqdn: dlink2.opensource.osu.edu
    ipv4: 10.0.194.3
network:
  - name: 'lan'
    subnet: 10.0.194.0/24
application: ''
---

# Switches

We need switches to connect our physical machines together. In case there are those that need a reminder, computers can't be directly connected to other computers (except with crossover cables, but that's outside the scope of this discussion). We have virtual routers, but the networks need to get out to the rest of our physical machines.

We will want managed switches, as we would want to allow for VLANs in the future, and control the access to the ports by systems administrators to prevent unauthorized access to various networks that the switches are connected to.

## dlinkswnw01lawo

Interfaces:
  - name: WAN
    ip: 10.0.3.5
    network: ADM

### Change Admin Password

`Management -> Password Access Control`

Root -> Systems -> opensource.osu.edu -> adm -> dlinkswnw01lawo -> admin

### Set IP Address

`System -> System Information Settings -> IPv4 Interface`

[X] Static

- IP Address: 10.0.3.5
- Mask: 255.255.255.0
- Gateway: 10.0.3.13

### Set hostname

`System -> System Information Settings -> System Information`

- System Name: dlinkswnw01lawo

### Access

Let's discuss port access. The switches should allow us to control access only to authorized devices. In short, we don't want an unauthorized user to walk in and plug into an ethernet port, and thereby get access to our internal networks - like the administrative or BLD network.

This should be done by MAC address learning.

### dlinkswnw01lawo

Security -> Port Security
  - Apply:
    - setup: Secure other ports
      From Port: eth2
      To Port: eth8
      Admin State: Enabled
      Max Learning Address: 0
    - setup: Secure first port auth
      From Port: eth1
      To Port: eth1
      Admin State: Enabled
      Max Learning Address: 1
L2 Features -> FDB -> MAC Address Table Settings:
  - Apply:
    - setup: Secure other ports
      From Port: eth2
      To Port: eth8
      State: Disabled
    - setup: first port auth
      From Port: eth1
      To Port: eth1
      State: Enabled

Connect the cable to the port that is meant to be there

`L2 Features -> FDB -> MAC Address Table`

Check 'Add' on correct MAC address and select 'Apply'. This is now the only MAC address that can be connected to the port.

#### The Switch May pick up additional MACs of virtual machines. If this is the case, increase the Max Learning Address number in Port Security to allow them, and add them as static in the MAC Address Table.

#### Disable entirely at System -> Port Configuration -> Port Settings

## Ports

1: Admin
2: Focault
3: Turing
4: Stallman
