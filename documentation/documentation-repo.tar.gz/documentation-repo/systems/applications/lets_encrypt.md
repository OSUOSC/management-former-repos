---
author: smacz
date: 2018-03-22
service: "Let's Encrypt"
discription: "Let's Encrypt handles our public X.509 PKI certificates. This involves pfSense as well as an external webserver to serve the dynamically generated challenge response page."
references:
  - title: 'Create the root pair'
    link: 'https://jamielinux.com/docs/openssl-certificate-authority/create-the-root-pair.html'
  - title: 'OpenSSL CA on an Ubuntu Server'
    link: 'https://networklessons.com/uncategorized/openssl-certification-authority-ca-ubuntu-server/'
  - title: 'Set Up Your Own CA on Linux'
    link: 'http://virtuallyhyper.com/2013/04/setup-your-own-certificate-authority-ca-on-linux-and-use-it-in-a-windows-environment/'
todo:
type: application
servers:
  - fqdn: letsencrypt.opensource.osu.edu
    services:
      - name: httpd
        port: 443
firewall: ""
network:
  - name: 'letsencrypt'
    subnet: 10.0.34.0/24
application: 'letsencrypt'
admin_group: 'letsencrypt_admins'
svc_accts:
  - name: 'cert_manager'
    shell: '/bin/sh'
    groups:
      - "cert_manager"
---

# Workflow

Since pfSense is acting as our Reverse Proxy, we are going to be terminating SSL at that point. In order to get the appropriate certificate installed on pfSense, we have to have a way to pass the automated challenge that Let's Encrypt offers.

This setup uses the Let's Encrypt "Acme Certificates" plugin, which uses a remote webserver to response to the Let's Encrypt challenge. The challenge passes through to that server, which response appropriately by putting the right file in the webserver directory, and then Let's Encrypt retrieves it. This is done by a subdirectory mapping which directs all inqueries destined for `opensource.osu.edu/.well_known` to `letsencrypt.opensource.osu.edu` for the challenge response.

The rest is magically handled by the plugin.

# Setup

## letsencrypt.opensource.osu.edu

```
# mkdir -p /home/cert_manager/public_html/.well-known/acme-certificates
# chown -R cert_manager:cert_manager /home/cert_manager
# chmod -R a+rX /home/cert_manager/public_html
# dnf install -y httpd
# firewall-cmd --permanent --add-service http
# firewall-cmd --reload
# sed -i 's/^User.*/User cert_manager/' /etc/httpd/conf/httpd.conf
# sed -i 's/^Group.*/Group cert_manager/' /etc/httpd/conf/httpd.conf
# sed -i 's#^DocumentRoot.*#DocumentRoot /home/cert_manager/public_html#' /etc/httpd/conf/httpd.conf
# sed -i 's#^<Directory "/var/www">.*#<Directory "/home/cert_manager/public_html">#' /etc/httpd/conf/httpd.conf
# systemctl enable httpd
# systemctl start httpd
```

## pfsense.opensource.osu.edu

Install `acme` package

**[Services]** -> **[Acme Certificates]**

**[Account keys]** -> **[Add]**

```yaml
- name: `open source club`
  description: `The private key certificate for our club's SSL certs from Let's Encrypt`
  Acme Server: `Production ACME v1`
  Email address: `opensource-announce@cse.ohio-state.edu`
  Account key: <private key>
```

**[Certificates]** -> **[New]**

```yaml
- name `osc_lets_encrypt`
  Status: `Active`
  Acme Account: `open source club`
  Key Size: `2048`
  Domain SAN list:
    - domain names:
      - opensource.osu.edu
      - www.opensource.osu.edu
      - opensource.cse.ohio-state.edu
      - www.opensource.cse.ohio-state.edu
    - Method: webroot FTP
      - Server: sftp://10.0.10.2
      - username: cert_manager
      - password: <password>
      - folder: /home/cert_manager/public_html/.well-known/acme-challenge/
```

**[General settings]**

```yaml
Cron Entry: [X]
Write Certificates: [X]
```

### Reverse Proxy Setup

**[Services]** -> **[Squid Reverse Proxy]** -> **[Redirects]** -> **[HTTPtoHTTPS]**

```yaml
- PathRegex: `^/[^.]*$`
```

**[Web Servers]** -> **[Add]**

```yaml
- Enable this peer: [X]
  Alias: letsencrypt
  IP: 10.0.10.2
  Port: 80
  Protocol: HTTP
  Description: Let's Encrypt certificate proof
```

**Mappings** -> **[Add]**

```yaml
- Enable This URI: [X]
  Group Name: letsencrypt
  Peers: letsencrypt
  URI:
  - `^http://opensource.osu.edu/.well-known`
  - `^http://www.opensource.osu.edu/.well-known`
  - `^http://opensource.cse.ohio-state.edu/.well-known`
  - `^http://www.opensource.cse.ohio-state.edu/.well-known`
```

# Renewal

The renewal should take place every 60 days. Assuming that all systems are set up appropriately, this should be done automatically. However, in my experience, only a reboot of the router was able to pick up the new cert after it was generated. Even a restart of the reverse proxy on the router itself didn't allow the cert to be renewed. Future renewals should test if there is an easier way to get the new certificate to be recognized by the service.
