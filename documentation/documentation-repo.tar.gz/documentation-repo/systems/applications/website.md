---
author: smacz
date: 2018-01-14
service: "Website"
description: "How our static website gets built and served."
references: ""
  title: "Set up an anonymous FTP server with vsftpd in less than a minute"
  link: https://www.g-loaded.eu/2008/12/02/set-up-an-anonymous-ftp-server-with-vsftpd-in-less-than-a-minute/
  title: "VSFTPD configuration file"
  link: https://security.appspot.com/vsftpd/vsftpd_conf.html
  title: "Ubuntu Help: FTP server"
  link: https://help.ubuntu.com/lts/serverguide/ftp-server.html
  title: "Reddit r/homelab: Reverse Proxy via Squid in pfsense"
  link: https://www.reddit.com/r/homelab/comments/2vyiiy/til_reverse_proxy_via_squid_in_pfsense/
  title: "FTP"
  link: http://slacksite.com/other/ftp.html
todo:
  - update with application-based network info
  - Secure vsftp
  - Ansible BLD setup
  - Ansible UI setup (httpd)
type: application
servers:
  - fqdn: website-ui.opensource.osu.edu
    files:
      - /srv/website
    services:
      - name: httpd
        port: 443
  - fqdn: website-bl.opensource.osu.edu
    files:
      - /opt/website
      - /srv/ftp
    services:
      - name: vsftpd
        port: 21
firewall: ""
network:
  - name: 'website'
    subnet: 10.0.64.0/24
application: 'website'
admin_group: 'website_admins'
svc_accts:
  - 'website_builder'
  - 'apache'
---

# Service Summary

This service provides an automated building and deployment strategy for osuosc's website that is built by Jekyll.

# Workflow

- Checkout website git repo on `websitebl01ubto.bld.opensource.osu.edu`
- Build static website files
- transfer files to `websiteui01fdto.dmz.opensource.osu.edu` via `ftp`
    - Can we used shared NFS instead?
- restart httpd

# App Setup

## `website-bl`

```
$ sudo apt update -y
$ sudo apt install -y ruby-dev libffi-dev apache2 git build-essential libxml2-dev zlib1g-dev vsftpd
$ sudo gem install bundler
$ sudo mkdir /opt/website /srv/website
$ sudo cd /opt/website
$ sudo git clone https://github.com/osuosc/website.git . # Don't forget the period here
$ sudo chown -R root:website_builder /{opt,srv}/website
$ sudo chmod -R g+w /{opt,srv}/website
$ sudo bundle install
$ bundle exec rake --trace gen_site
$ cp -r _site/* /srv/website/
$ sudo sed -i 's/^anonymous_enable.*/anonymous_enable=Yes/' /etc/vsftpd.conf
$ sudo usermod -d /srv/website ftp
$ sudo systemctl restart vsftpd
$ sudo systemctl stop vsftpd
```

## `website-ui`

```
$ sudo dnf install -y wget
$ sudo mkdir /srv/website
$ sudo chown -R root:website_builder /srv/website
$ sudo chmod -R g+w /srv/website
$ wget -mP /srv/website --no-host-directories ftp://website-bl.opensource.osu.edu
```

`httpd` setup via ansible role for `/srv/website` as `https://opensource.osu.edu/` and `https://www.opensource.osu.edu/`.

# Maintenance

## Deploy Website

### `website-bl`

```
$ cd /opt/website
$ git pull
$ bundle exec rake --trace gen_site
$ cp -r _site/* /srv/website/
```

### `website-ui`

```
$ wget -mP /srv/website --no-host-directories ftp://website-bl.opensource.osu.edu
```


# Ansible

## Server Plurality

Single server: can serve content directly from `/srv/website`

Two/Three tier: UI server can `FTP` from BLD host

#### Alternatively we could have the BLD host running a webserver, and have the DMZ server be a simple proxy to that BLD server. However, we decrease network traffic, as well as speed up I/O time if we just store the files on the DMZ server. Since they're flat static files, they should be considered ephemeral - the ones on the BLD server are cononical.
