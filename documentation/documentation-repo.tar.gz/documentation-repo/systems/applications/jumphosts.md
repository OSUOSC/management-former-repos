---
author: smacz
date: 2018-01-14
service: "Ansible"
description: "This document describes how to set up a server to be a CNC server for Ansible."
type: infrastructure
references: ""
todo:
  - Add volume for ansible files
---

# Install virtualenv

```
$ sudo dnf install -y gcc git python2 python2-devel openssl-devel openldap-devel sshpass;
pip install --user --upgrade pip virtualenv virtualenvwrapper;
echo -e "PATH=~/.local/bin:$PATH\nsource ~/.local/bin/virtualenvwrapper.sh" > ~/.bashrc;
. ~/.bashrc;
git clone https://github.com/oscziryak/ansible;
mkvirtualenv --python=/usr/bin/python2 ansible;
echo "cd ~/ansible" >> ~/.virtualenvs/ansible/bin/postactivate;
workon ansible;
pip install ansible==2.4.4 python-ldap passlib;
sudo mkdir -p /var/log/ansible/;
sudo chmod -R 666 /var/log/ansible;
```
