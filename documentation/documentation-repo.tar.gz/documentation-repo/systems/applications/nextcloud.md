---
author: oscziryak
date: 2018-08-15
service: "Nextcloud"
discription: "This is the setup of the nextcloud servers"
references:
  - title: "Configure LDAP authentication in Nextcloud with FreeIPA"
    link: 'https://alexandre.deverteuil.net/blogue/configure-ldap-authentication-in-nextcloud-with-freeipa/'
  - title: "Owncloud Authentication against FreeIPA"
    link: 'https://www.freeipa.org/page/Owncloud_Authentication_against_FreeIPA'
  - title: "Integrating NextCloud 11 with FreeIPA 4"
    link: 'http://poorlydocumented.com/2017/02/integrating-nextcloud-11-with-freeipa-4/'
  - title: "User authentication with LDLAP - Nextcloud 13 Admin Manual"
    link: 'https://docs.nextcloud.com/server/13/admin_manual/configuration_user/user_auth_ldap.html'
todo:
  - FreeIPA auth integration
  - Remote storage on FreeNAS
    - DB server
    - raw file storage
type: application
servers:
  - fqdn: nextcloud-ui.opensource.osu.edu
    services:
      - name: httpd
        port: 443
    data-mounts:
      - name: 'nextcloud-ui-data'
        location: '/var/www/nextcloud/data'
  - fqdn: nextcloud-db.opensource.osu.edu
    services:
      - name: mariadb
        port: 3306
    data-mounts:
      - name: 'kanboard-db-mysql'
        location: '/var/lib/mysql'
firewall: ""
network:
  - name: 'nextcloud'
    subnet: 10.0.70.0/24
application: 'nextcloud'
admin_group: 'nextcloud_admins'
svc_accts:
  - 'nextcloudbind'
---

# Installation

## UI/BL server

Ubuntu 16.04

https://docs.nextcloud.com/server/13/admin_manual/installation/source_installation.html#example-installation-on-ubuntu-16-04-lts-server

Make sure you apt-get update first, otherwise your sources won't have some of the pkgs.

https://nextcloud.com/install

https://download.nextcloud.com/server/releases/nextcloud-13.0.5.zip
https://download.nextcloud.com/server/releases/nextcloud-13.0.5.zip.md5
https://nextcloud.com/nextcloud.asc

apt install unzip

Set up DB before running `occ` command to install nextcloud.
* MySQL since it seems to be the default non-sqlite db

## DB Server

https://www.marksei.com/install-nextcloud-13-centos-7/

`remote_ip_range` can look like [this](https://mariadb.com/kb/en/library/configuring-mariadb-for-remote-client-access/#granting-user-connections-from-remote-hosts)

```
yum install -y mariadb-server
systemctl start mariadb
systemctl enable mariadb
mysql_secure_installation
	root_pw: <blank>
	Set Root Passwd: Y
	New Passwd: <mariadb_root_passwd> (root_pw)
	Re-enter new Passwd: <mariadb_root_passwd>
	Disable Anon users: Y
	Disable remote root login: Y
	Remove test DB & access: Y
	Reload priv tables: Y
mysql -u root -p
	CREATE DATABASE nextcloud;
	CREATE USER 'nc_user'@'<remote_ip_range' IDENTIFIED BY 'YOUR_PASSWORD_HERE';  # (nc_user_pw)
	GRANT ALL PRIVILEGES ON nextcloud.* TO 'nc_user'@'remote_ip_range';
	FLUSH PRIVILEGES;
```

## UI/BL Server

Add `--database-host` to the list of args to put the DB on another host

```
cd /var/www/nextcloud
sudo -u www-data php occ  maintenance:install --database "mysql" --database-name "nextcloud"  --database-user "nc_user" --database-pass "<nc_user_passwd>" --admin-user "admin" --admin-pass "<admin_passwd>"  # (admin_pw)
vim config/config.php
  // If you're going to be putting this behind a reverse proxy, make sure to add the following line:
  'trusted_proxies' =>
  array (
    0 => '10.0.70.1',
  ),
  // Add the following lines as necessary based on how you're accessing the frontend
  'trusted_domains' =>
  array (
    0 => 'localhost',
    1 => 'nextcloud-ui.opensource.osu.edu',
    2 => 'opensource.osu.edu',
    3 => 'www.opensource.osu.edu',
    4 => 'www.opensource.cse.ohio-state.edu',
    5 => 'opensource.cse.ohio-state.edu',
  ),
a2enmod ssl
a2ensite default_ssl
```

Now, you should be able to log into the default site.

# App Admin Setup

# FreeIPA Auth

There's a shit ton to do to set this up to auth to FreeIPA, but right now I just did _this_, so I'm writing it down:

## Installation

In **[Apps]**, install **[LDAP/AD Integration]**. Then, manage it from the admin user's **[Settings]** -> **[LDAP/AD Integration]**.

## Configuration

Server: `freeipa.opensource.osu.edu`: `389`
DN: `uid=nextcloudbind,cn=users,cn=accounts,dc=opensource,dc=osu,dc=edu`
Password: <password>

Alexandre de Verteuil's blog post has everything except the Group-Member association bit in it.

For the FreeIPA integration to LDAP, Under *[Advanced] -> [Directory Settings]* the *Group-Member association* needs to be `uniqueMember`. This is the attribute that FreeIPA creates when you "add" a user to a group.

## LDAP Admins

For the time being, there is no way to grant users admin status by adding them to a group in LDAP - it has to be done in Nextcloud itself.

[Watch this issue in the future](https://github.com/nextcloud/server/issues/3877)

# Mainenance

## Upgrade Version

When logging in as an admin, there should be an announcement if there is a new version available. This will walk you through the upgrade process.

If you want to manually start the upgrade process as an admin, go to [Settings] -> [Basic Settings] and see what the 'update check' says. It should provide you a button to start the upgrade if it's ready to do so.

# References:

[FreeIPA Integration](https://www.freeipa.org/page/Owncloud_Authentication_against_FreeIPA)
