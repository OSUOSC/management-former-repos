---
author: oscziryak
date: 2018-09-16
service: "Kanboard"
discription: "This is the setup of the kanboard servers"
references:
  - title: 'How to Install PHP 7 in CentOS 7'
    link: 'https://www.tecmint.com/install-php-7-in-centos-7/'
  - title: "Installation on RedHat/Centos/Oracle Linux Enterprise — Kanboard documentation"
    link: 'https://docs.kanboard.org/en/latest/admin_guide/rhel_installation.html'
  - title: "Mysql Command-line client"
    link: 'https://mariadb.com/kb/en/library/mysql-command-line-client/'
  - title: "MySQL/MariaDB — Kanboard documentation"
    link: 'https://docs.kanboard.org/en/latest/admin_guide/mysql.html'
  - title: "How to Setup LDAP in Kanboard"
    link: 'https://linoxide.com/ubuntu-how-to/setup-kanboard-ubuntu-16/'
todo:
  - FreeIPA auth integration
  - Remote storage on FreeNAS
    - DB server
    - raw file storage
type: application
servers:
  - fqdn: kanboard-ui.opensource.osu.edu
    services:
      - name: httpd
        port: 443
    data-mounts:
      - name: 'kanboard-db-mysql'
        location: '/var/lib/mysql'
  - fqdn: kanboard-db.opensource.osu.edu
    services:
      - name: mariadb
        port: 3306
    data-mounts:
      - name: 'kanboard-ui-files'
        location: '/var/www/html/kanboard/data/files'
firewall: ""
network:
  - name: 'kanboard'
    subnet: 10.0.80.0/24
application: 'kanboard'
admin_group: 'kanboard_admins'
svc_accts:
  - 'kanboarduser'
---

# Installation

## UI server

First, install the repos for PHP7.

Then follow the instructions to install the files.

## DB Server

First, install and start MariaDB with the initial `mysql_secure_installation` command. No need to add any extra repos here.

Then, follow the installation steps to set up the Kanboard instance with a mysql connection. 

## Remote LDAP Authentication

The whole problem here is that kanboard cannot create LDAP users in its own mysql database. Why the fuck that is I don't know, 'cause that's fucking stupid. So we're setting up a cron job to do that for all of our users, just in case they're not there already.

```shell
#!/bin/bash

#
# Script that adds remote ldap users to a Kanboard instance, since Kanboard cannot do that automagically for us.
#
# Author: oscziryak (cziryak.1@buckeyemail.osu.edu)
# Date: 2018-09-18
#

# We're searching members and officers since our advisors are only in `officers`, not `members`. If we need to add another on in the future (perhaps `alumni`?) then we can certainly expand this to include the members of that group as well.
for i in members officers; do
        # This is _very_ specific to FreeIPA, as far as the location of these users
        ldapsearch -ZZ -D "uid=kanboardbind,cn=users,cn=accounts,dc=opensource,dc=osu,dc=edu" -H ldap://freeipa.opensource.osu.edu -b "cn=${i},cn=groups,cn=accounts,dc=opensource,dc=osu,dc=edu" -w <password>;
done |\
        # We grab all of the members that are a part of that group
        grep '^member: ' |\
        # This prints their DN
        awk '{print $2}' |\
        # We only want one of each
        sort -u |\
        # The next two cut them down into only their uid, and then redirect that into our list
        cut -d ',' -f 1 |
        cut -d '=' -f 2 > /home/kanboardbind/ldap_users/users_list.txt

# Here we are creating the sql commands from the list of users that we got earlier
for i in $(cat /home/kanboardbind/ldap_users/users_list.txt); do
        # Create the sql commands
        cat << EOF > /home/kanboardbind/ldap_users/add_user_${i}.sql
insert into users (username, is_ldap_user) VALUES ('${i}',1);
EOF
done

# TODO: We should do something here that stops them from getting added if they're already there. Otherwise we get:
#       ```
#       ERROR 1062 (23000) at line 1: Duplicate entry 'oscziryak' for key 'users_username_idx'
#       ```
#
# Import all of the users into the database using the dynamically-generated files that we created for them
for j in $(ls /home/kanboardbind/ldap_users/add_user*.sql | grep add_user); do
        mysql -u kanboard_user -p<password> kanboard < ${j};
done
```

Then add this as a crontab:

```
*/3 * * * * /home/kanboardbind/ldap_users/populate_ldap_users.sh
```

## App Admin Setup

As an admin, make sure to change their status to Admin in the setup

# Mainenance

## Backup

On the `kanboard-db` server:

```bash
$ mysqldump kanboard > kanboard-$(date +%Y-%m-%d).sql
```

## Restore

Assuming that we have a sql dump:

```bash
$ mysql -u kanboardbind -p<password> kanboard < kanboard-$(date +%Y-%m-%d).sql
```

## Upgrade Version
