---
author: smacz
date: 2018-08-28
service: "FreeIPA"
description: "This service provides SSO authentication to the individual machines in the network as well as to the services that it serves."
references:
  - title: 'RedHat - Linux Domain Identity, Authentication, and Policy Guide'
    link: 'https://access.redhat.com/documentation/en-us/red_hat_enterprise_linux/7/html/linux_domain_identity_authentication_and_policy_guide/index'
todo:
  - mainenance on how to add users
  - what groups are important
  - how to enable automatic homedir creation
type: infrastructure
servers:
  - fqdn: freeipa.opensource.osu.edu
    services:
      - name: httpd
        port: 443
      - name: ldap
        port: 389
      - name: ntp
        port: 123
      - name: kerberos
        port: 88
firewall: ""
network:
  - name: 'freeipa'
    subnet: 10.0.33.0/24
application: 'freeipa'
admin_group: 'admins'
svc_accts:
  - 'apache'
---

# Firewall Rules

  - rule: Allow all to LDAP
    interface: Internal (all)
    port: any
    src: 10.0.0.0/16
    dst: 10.0.33.0/24
    protocol: IPv4 TCP
  - rule: Allow all to HTTP/S
    interface: Internal (all)
    port: any
    src: 10.0.0.0/16
    dst: 10.0.33.0/24
    protocol: IPv4 TCP

# Workflow

- Manage accounts via GUI
- Authenticate via accounts in system

# App Setup

## Bare Setup

https://www.digitalocean.com/community/tutorials/how-to-set-up-centralized-authentication-with-freeipa-on-centos-7

This redirects to a subdirectory, and hardcodes the hostname into the URL, so this can only be accessed from inside the network, which is probably fine, given that we probably don't want to expose this publicly.

## Nextcloud

http://poorlydocumented.com/2017/02/integrating-nextcloud-11-with-freeipa-4/
https://alexandre.deverteuil.net/blogue/configure-ldap-authentication-in-nextcloud-with-freeipa/
https://www.freeipa.org/page/Owncloud_Authentication_against_FreeIPA
https://www.redhat.com/archives/freeipa-users/2015-April/msg00186.html

The server URI should include `ldap://` since otherwise it seems to fail on searching for users.

# Set up sssd for FreeIPA

```
ipa-client-install --server=freeipa.opensource.osu.edu --domain=opensource.osu.edu -p admin --mkhomedir
```

Look in the keepass file for the admin password. Otherwise, replace `admin` with your own password.

#### Note that I've only ever tested this with a sysadmin account. General member accounts may not have sufficient privs to register a server.

# Log into the jumphost to change your password

In order to log into the jumphost, you have to connect to `opensource.osu.edu` on port 2222, and use your login to log into the server, for instance:

```
ssh oscziryak@opensource.osu.edu -p 2222
```

This will then forward you to the jumphost, and allow you to log in using the initial password that was given to you. Luckily, FreeIPA is smart enough to know that the password that was given needs to be changed ASAP! So it will (on login) prompt you to change your password. After entering in your previous password, and twice entering in your new password, your password should be changed for all logins that use the FreeIPA instance as a backend (Nextcloud, etc.)

# Ansible

## Server Plurality
