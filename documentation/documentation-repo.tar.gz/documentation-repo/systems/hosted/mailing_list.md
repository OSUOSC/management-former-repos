---
author: smacz
date: 2018-01-14
service: "Mailing List"
description: "The CSE department maintains our mailing list on a mailman instance. These are the details of that account."
references: ""
todo: ""
type: hosted
url: https://mailman.cse.ohio-state.edu/mailman/listinfo/opensource
---

# Mailing list administration

This is the comprehensive view of everything that's relevant to the maintenance of the mailing list. It's a bit all over the place, so just search for whatever you're looking to do. Maybe it'll get better organized in the future.

This is administration - moderation should be covered in the other docs.

# URLs

## opensource-announce@

- Front Page: http://mailman.cse.ohio-state.edu/mailman/listinfo/opensource-announce
- Archives: http://mailman.cse.ohio-state.edu/mailman/private/opensource-announce/
- Admin Interface: http://mailman.cse.ohio-state.edu/mailman/admin/opensource-announce

## opensource@

- Front Page: http://mailman.cse.ohio-state.edu/mailman/listinfo/opensource
- Archives: http://mailman.cse.ohio-state.edu/pipermail/opensource/
- Admin Interface: http://mailman.cse.ohio-state.edu/mailman/admin/opensource

# Emergency Halt to all Messages

"General Options" -> "Additional Settings" -> "Emergency moderation of all list traffic" == 'Yes'

> When this option is enabled, all list traffic is emergency moderated, i.e. held for moderation. Turn this option on when your list is experiencing a flamewar and you want a cooling off period.

# Membership Management

## Add a member

"Membership Management" -> "Mass Subscription" -> Fill in the boxes

## Remove a member

"Membership Management" -> "Membership List" -> Find email address -> Check "unsub" box -> Submit Your Changes

Members should be able to unsubscribe themselves. They should be directed to the list base URL where they can unsubscribe themselves.

> To unsubscribe from opensource-announce, get a password reminder, or change your subscription options enter your subscription email address:

## Other member options

### Targeted moderation

If all of a user's emails needs to be moderated for some reason, check the "mod" box by their username on the "Membership List", and all of their emails will be sent to the admins and mods for approval before being sent to the list.

### Change email address

"Membership Management" -> "Address Change"

Please be courteous and sent notices to both addresses (unless one of them is no longer active).

# Archives

All of our mailing lists are archived by month. opensource@ is public, opensource-announce@ has been made private. These should always be left intact. After all, it's not our own disk space that's holding onto these.

# Content Filtering

Attachments of certain types are not allowed. `exe`, `bat`, and `pl` are among them. (Perl sucks) This can and should be further limited in the future.

Actually, this should be switched to a white-listing if possible in the future.

# TODO: A lot more helpful documentation

# Other Documentation

- `opensource@cse.ohio-state.edu` Public Mailing List
- `opensource-announce@cse.ohio-state.edu` Private Officer's Mailing List
