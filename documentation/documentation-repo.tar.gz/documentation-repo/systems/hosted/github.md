---
author: smacz
date: 2018-01-14
service: "Github"
description: "We host our git repos on Github. Here are the details of what goes in there and how to administer it."
type: hosted
references: ""
todo: ""
url: https://github.com/osuosc
---
# Github

https://github.com/osuosc

# Adding a new user

https://github.com/orgs/OSUOSC/people

"Invite Member"

Assign to group

Can visit https://github.com/osuosc to accept without having to wait for an email.

# Maintenance

Only current officers and advisors should be owners of the org. All other (previous) officers should be regulated to a
'members' role.
