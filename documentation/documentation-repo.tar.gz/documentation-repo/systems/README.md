# Systems

The following directories hold documentation about the various systems that the OSC uses to get their work done. It is up to the officers to keep them running. It is probably easiest to review them in the order that they are presented here, as the design decisions may not make sense out of order.

## Infrastructure

## Network

## Applications

## Hosted
