Involvement Fair Required Checklist:
* Did you Register? (Opens in November for Spring Involvement Fair & April for Fall Involvement Fair
* Officer Scheduled Tabling hours (when is each officer scheduled to be at the table?)
* Sign up Sheet (Never forget the sign up sheet)
* Flyers

Involvement Fair Optional Checklist:
* Bander/Trifold ( as of Jan 2018, OSC has a bander to put on the table. Could look into a trifold since every other club at these fairs have one)
* Swag (laptop stickers, tshirts from companies, etc. Used to attract people to the table)


Tips:
* Plan ahead (get the Required checklist and Optional checklist all together a head of time)
* Delegate a person to set up and check in the day of the event, if not you'll lose the table
* have swag, can be used to break the ice with people ("Hey do you want a ___? Just sign up")


Here is a link to registeing for involvement fairs: https://activities.osu.edu/programs/major_campus_events/student_involvement_fairs/
This document describes the details of the event and what to do to register for the event.

An event registration window will open (primary contact, secondary contact) and immedietly signing up will give you a spot at the event. 
Details will follow in an email to the two primary contacts for the event.
