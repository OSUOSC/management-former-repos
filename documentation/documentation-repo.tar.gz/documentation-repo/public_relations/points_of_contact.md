# Points of contact

## Responsibilities

There are different kinds of contacts and different club members should be responsible for the initial contact. Of course, there should be one office who coordinates the meeting schedules, etc., but sometimes it's better to divvy up the initial contact to those who are best suited for it.

```yaml
- Prez - Clubs
- PR Officer/VP - Companies
- Sysadmin/Librarian - Alumni
```

## Contacts

```yaml
- name: Robert Ball
  email: rball@ohiolinux.org
  rationale: Ohio Linuxfest Organizer
- name: DK Panda
  email: panda@cse.ohio-state.edu
  rationale: Ohio State Professor of Networking and High Performance Computing
- name: Dave Forgac
  email: dforgac@pyohio.org
  rationatle: Main Organizer of PyOhio
- name: Eric Floehr
  website: intellovations.com
  email: eric@intellovations.com
  rationale:
    - PyOhio Treasurer
    - Ohio Linuxfest Sponsor
- name: Brian Costlow
  email: brian.costlow@gmail.com
  rationale: PyOhio Former Organizer
- name: Hali Buck
  email: buck.180@osu.edu
  rationale: Ohio State Union POC for Union with PyOhio
- name: Maria Maiorana
  email: mmaiorana@covermymeds.com
  rationale: CoverMyMeds Technical Recruiter
- name: Bryan Arendt
  email: barendt@covermymeds.com
  rationale: CoverMyMeds Senior Developer
- name: Hayley Ford
  email: hayley.ford@capitalone.com
  rationale: Capital One Recruiter - Club's Main POC
- name: Ngan Pham
  email: ngan.pham@capitalone.com
  rationale: Capital One Campus Recruiter
- name: Zach Boerger
  email: zach@drivecapital.com
  rationale:
    - Drive Capital
    - Ran a few College Tech Meetup
- name: Jonathan `J3RN` Arnett
  email: jonathan.arnett@protonmail.com
  rationale:
    - Alumni of Club
    - Ruby Developer/CMM
- name: Mark Tareshawty
  email: mark@marktareshawty.com
  rationale:
    - Github
- name: Alex `satarus` Burkhart
  email: alex@alexburkhart.com
  rationale:
    - MariaDB
    - Alumni
- name: Daniel `paradigm` Thau
  email: ''
  relationship: Alumni
  rationale: Former OSC prez(?)
- name: Dan Zelenikar
  email: 
  relationship:
  rationale:
- name: Eli Gladman
  email:
  relationship: Alumni
  rationale: Former OSC prez
- name: Jeff Cosavant
  email:
  relationship:
  rationale: Postgresql
- name: John Totarhi
  email:
  relationship:
  rationale: Batelle
- name: David Stanek
  email: dstanek@dstanek.com
  relationship: Prior presentation at OSC; From Cleveland
  rationale: Openstack
- name: John Simerlink
  email: simerlink.3@osu.edu
  relationship: Former Member
  rationale: 
- name: Naila Zaman
  email: nzaman@harris.com
  relationship: 
  rationale: Harris
- name: Naila Zaman
  email: nzaman@harris.com
  relationship: 
  rationale: Harris
- name: Matt Curtin
  email: cmcurtin@interhack.com
  relationship: Previous presentation at OSC;
  rationale: Interhack
- name: Graycore
  email: hello@graycore.io
  relationship: Previous presentation at OSC;
  rationale: Webdev consultants
- name: Tarus Balog
  email: tarus@opennms.org
  relationship: Previous presentation at OSC;
  rationale: OpenNMS
- name: Stephen Haffner
  email: stephen@kd8zev.net
  relationship: Alumni
  rationale: Sysadmin
- name: Kevin Payravi
  email: kevinpayravi@gmail.com
  website: https://en.wikipedia.org/wiki/Wikipedia:Wikipedia_Connection
  rationale:
    - Wikipedia Connections
    - Alumni
- name: Chandler Freeman
  email: ?
  website: ?
  rationale: ?
- name: William `librewulf` Osler
  email: osler.6@buckeyemail.osu.edu
  rationale: Alumni
- name: Ben `Boom_Farmer` Keith
  email: keith.146@buckeyemail.osu.edu
  rationale:
    - Alumni
    - Wordpress and PHP
- name: Nikit `Nefari0uss` Malkan
  email: malkan.1@osu.edu
  rationale: Alumni
- name: Eli `httpstr` Gladman
  email: gladman.23@osu.edu
  rationale: Previous President
- name: Brian Swaney
  email: swaney.29@osu.edu
  rationale: Previous Sysadmin
- name: Matt Meinwald
  email: meinwald.1@osu.edu
  rationale: Previous President
- name: Matt Meinwald
  email: meinwald.1@osu.edu
  rationale:
    - Previous President
    - Previous Presentation on Xen
- name: Jeff Casavant
  email: 
  website: https://jeffcasavant.com/
  rationale:
    - DevOps
    - Python
    - Network Engineering
- name: Jeff Frontz
  email: jeff.frontz@gmail.com
  website: columbuscodecamp.com
  rationale: ?
- name: Andrew Haninger
  email: haninger.3@osu.edu
  rationale:
    - Alumni
    - http://mailman.cse.ohio-state.edu/pipermail/opensource/2015-February/002251.html
- name: OnShift
  email: info@onshift.com
  website: onshift.com
  rationale:
    - Ohio Linuxfest Sponsor
- name: Truthful Technology
  email: hello@truthful.technology
  website: truthful.technology
  rationale:
    - Ohio Linuxfest Sponsor
- name: JPMorgan Chase & Co
  email: media.requests@jpmorgan.com
  website: jpmorganchase.com
  rationale:
    - Ohio Linuxfest Sponsor
- name: Wingware
  email: info@wingware.com
  website: wingware.com
  rationale:
    - Ohio Linuxfest Sponsor
- name: Bob Fenner
  email: bobf@arista.com
  website: arista.com
  rationale:
    - Ohio Linuxfest Sponsor
- name: Chris Kane
  email: ckane@arista.com
  website: arista.com
  rationale:
    - Ohio Linuxfest Sponsor
- name: Chris Kane
  email: ckane@arista.com
  website: arista.com
  rationale:
    - Ohio Linuxfest Sponsor
```
