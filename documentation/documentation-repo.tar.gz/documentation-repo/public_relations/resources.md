[![Awesome](https://cdn.rawgit.com/sindresorhus/awesome/d7305f38d29fed78fa85652e3a63e154dd8e8829/media/badge.svg)](https://github.com/sindresorhus/awesome)

# OSC resources
>This repository contains a list of awesome resources, many of which have been offered as print-outs in club meetings. If you know of a resource that would be awesome for members, then feel free to make a pull request to add to this list or make an issue requesting a resource on something.

__Cheatsheets__
* [Meta](#meta)
* [Text Editors](#text-editors)
    * [Vim](#vim)
    * [Emacs](#emacs)
* [Languages](#languages)
    * [Markdown](#markdown)
    * [LaTeX](#latex)
    * [Python](#python)
    * [Bash](#bash)
    * [Ruby](#ruby)
    * [Java](#java)
* [Programs](#programs)
    * [Git](#git)

-----------------------------------------------------

### Meta

**[`^        back to top        ^`](#)**

- [Cheatsheet Collection for Full Stack Developers](http://www.idiotinside.com/2014/09/29/cheatsheet-collection-for-full-stack-developers/) - Cheatsheets for many additional subject areas. `html`

#### Linux
- [Linux One page manual](http://www.digilife.be/quickreferences/QRC/The%20One%20Page%20Linux%20Manual.pdf) - Short and sweet reference for the command line. `2 pg pdf`
- [OSUOSC Command-line-introduction](https://github.com/OSUOSC/command-line-introduction) - OSUOSC's homemade command line introduction. `markdown`

### Text Editors

**[`^        back to top        ^`](#)**

#### Vim
- [Complex Vim Cheatsheet](http://michael.peopleofhonoronly.com/vim/) - Keyboard layout reference for Vi/Vim keybindings. `1 pg pdf`
- [Simplified Vim Cheatsheets](http://www.viemu.com/a_vi_vim_graphical_cheat_sheet_tutorial.html) - Multiple keyboard layout references for vi/vim keybindings. `1 pg pdf`

#### Emacs
- [Gnu Emacs Reference Card](https://www.gnu.org/software/emacs/refcards/pdf/refcard.pdf) - A dual-sided cheat sheet for gnu emacs. `2 pg pdf`


### Languages

**[`^        back to top        ^`](#)**

#### Markdown
- [Github MarkDown cheatsheet](https://guides.github.com/pdfs/markdown-cheatsheet-online.pdf) - A cheatsheet for github flavored markdown. `2 pg pdf`

#### LaTeX
- [Double sided cheatsheet](https://wch.github.io/latexsheet/latexsheet.pdf) - LaTeX Cheatsheet. `2 pg pdf`

#### Python
- [Python Awesome-List](https://github.com/vinta/awesome-python) - Python Cheatsheet 1. `awesome-list`
- [Python Basics](http://www.cogsci.rpi.edu/~destem/igd/python_cheat_sheet.pdf) - Python Cheatsheet 2. `3 pg pdf`
- [Python Built-ins](https://www.cheatography.com/davechild/cheat-sheets/python/pdf_bw/) - Python Cheatsheet 3. `2 pg pdf`
- [Python 3 Cheatsheet](https://perso.limsi.fr/pointal/_media/python:cours:mementopython3-english.pdf) - Python Cheatsheet 4. `2 pg pdf`
- [Python Cheat Sheet by RGruet](http://rgruet.free.fr/PQR26/PQR2.6.html) - Python Cheatsheet 5. `html`

#### Bash
- [BashSheet](http://mywiki.wooledge.org/BashSheet) - Bash cheatsheet 1. `html`
- [Unix/Linux Command Reference](https://files.fosswire.com/2007/08/fwunixref.pdf) - unix/linux command reference. `1 pg pdf`
- [Top 10 best Unix/Linux cheatsheets](https://www.cyberciti.biz/tips/linux-unix-commands-cheat-sheets.html) - Other bash cheatsheets. `html`

#### Ruby
- [cs.cmu.edu Ruby Reference](https://www.cs.cmu.edu/~tcortina/15110f11/rubyreference.pdf) - Ruby reference 1 `2 pg pdf`
- [Ruby on Rails cheatsheet](http://www.cheat-sheets.org/saved-copy/RubyOnRails-Cheatsheet-BlaineKendall.pdf) - Ruby on rails reference. `14 pg pdf`
- [Ruby Language Quick Reference](http://www.digilife.be/quickreferences/qrc/ruby%20language%20quickref.pdf) - Quick ruby reference. `2 pg pdf`

#### Java
- [Dream-in-code Java Reference Sheet](http://www.dreamincode.net/downloads/ref_sheets/java_reference_sheet.pdf) - Java reference 1. `1 pg pdf`
- [Digilife.be JAVA Programming Guide](http://www.digilife.be/quickreferences/QRC/JAVA%20Programming%20Guide%20-%20Quick%20Reference.pdf) - Java reference 2. `11 pg pdf`

### Programs

**[`^        back to top        ^`](#)**

#### Git
- [Github's Git Cheat Sheet](https://services.github.com/on-demand/downloads/github-git-cheat-sheet.pdf) - Github's git workflow cheatsheet. `2 pg pdf`
- [Git Quick Reference](http://www.cheat-sheets.org/saved-copy/Git_Quick_Reference.2011-09-04.pdf) - git quick reference. `1 pg pdf`
- [zrusin of KDE's Git Cheat Sheet](http://byte.kde.org/~zrusin/git/git-cheat-sheet-medium.png) - Git cheat sheet used by KDE developers. `png`
