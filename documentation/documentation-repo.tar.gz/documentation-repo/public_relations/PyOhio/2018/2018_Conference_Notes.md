# PyOhio 2018
## July ??th - ??th
## At the Ohio Union

# Contacts

Dave Forgac - PyOhio chair
dforgac@pyohio.org

# Pre-event task

Set up as Non-Profit sponsor.

# We need to get involved more

- Determine which talks are going to be given
