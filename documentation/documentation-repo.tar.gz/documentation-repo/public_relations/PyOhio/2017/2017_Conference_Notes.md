# PyOhio 2017
## July 29th - 30th
## At the Ohio Union

We first found out about PyOhio from our advisor Carey Black after we were voted in as officers. The previous president had not told us anything about the matter.

Our role in the conference - summed up in one phrase - was to act as the liason between the PyOhio Organizers, the hired A/V videographers ("Next Day Video" - aka NDV), and the Union staff.

The schedule for us was a three-day event. A half-day on Friday in the evening to set up, and a full day Saturday and Sunday.

# Who's who?

## Union Staff

### Event Coordinator

The Union staff consisted of several people who we had to work with. The first was the event coordinator. This year it was [Hali (read: Hayley) Buck](mailto:buck.180@osu.edu). She was the first one that we met in our workings with the Union.

About two months out from the event, we met to discuss logistics with Hali. She gave us a rundown of the days and rooms that we had available to us, and even took us on a tour at the end of the meeting. She also talked about the details of shipping anything hear, and the setup/loadout that would bookend the event. Lastly, she went over some concerns that had been raised about the previous year's proceedings, and how we might mitigate them this year. In particular there was a concern about almost having OSU's cables getting mixed up with the NDV's cables, and general confusion around the entire A/V setup. Luckily that didn't seem to be a problem this year.

Also, by the time we met with her, there were several forms that were needing to be filled out by the OSC. Namely we had to start the approval process of the reservation (see the 2017 invoice) and get the Co-Sponsor form returned a month prior to the event.

During the conference, she was present during the setup on Friday and the beginning of Saturday, as discussed below in [Walkthrough](#Walkthrough).

### Rooms

There were several rooms that PyOhio took up. The ones with A/V and the major talks were:

- Cartoon1
- Cartoon2
- Susan Sharer
- Barbie Tootle

Cartoon 1&2 were able to be split up or combined depending on what size room we needed. Basically it was split for all of the talks except for the Lightning talks at the end of both days, and the Keynote at the beginning of the conference.

Also, There was a room set up for young coders - a day long programming camp for 13-18-yr olds. This was one of the side rooms. The other two rooms were reserved for open talks, and a quiet room. They weren't used so much, but they were available.

As a side note, there was a concern to see if the lactation room would be available for one of the organizers wife who was planning on coming with their (going-to-be) newborn to the conference. We were assured that it would be. However, she did not end up coming, so we didn't find out if this was the case.

### A/V

Before the conference, we also had to meet with the A/V Union rep to discuss specifics. This was a bit more difficult as there was no one in the club who was particularly proficient in A/V, but we got along fine enough.

First, we contacted NDV company about their preferences. They gave us a list of concerns and we relayed them to the A/V rep. This was probably the least successful communication on our part. Even Brian mentioned it afterwards that it's always been a pain point to get the two A/V teams talking. And that any middleman always ends up being nothing more than another man in the game of Telephone.

Despite that, most of the communication went fine enough between the two.

### Building Manager

The Building manager was the title of the person who could call the relevant people to help us. For instance, if we needed any A/V support, we could call the building manager and have them send up the A/V team to the correct place. Or if we needed more water, we could have them send up catering. They also helped us with our program incident as discussed below in [Walkthrough](#Walkthrough)

This person was never the same between days, but had the same phone number. This year it was (614) 402-4335. Either way, Hali was able to give that to us beforehand.

### A/V Lead

During the conference days, there was an A/V lead who was in charge of any troubleshooting that was required. This wasn't the same A/V rep, but he knew all that was required during the conference. Once again, I would have liked to see better communication between OSC and the Union's A/V, but as long as we could call A/V whenever NDV needed us to, they seemed to work fine together.

## PyOhio Team

### NDV

While not directly associated with the PyOhio organizers, Next Day Video has been mentioned enough already to be introduced. [Carl Karsten](mailto:carl@nextdayvideo.com) was the main contact with them. He brought all the A/V equipment and set everything up.

Carl is a _really_ great guy, but he can be a bit eccentric, and we found that it helped to have our SysAdmin be his right-hand man during the setup in order to contact the building manager to call for A/V whenever it was necessary.

### Brian Costlow

Brian was our main point of contact for the PyOhio organizers group. He had been running PyOhio for the last several years, but wanted to take a step back and not have so much to deal with during the conference. We were happy to take over several of his responsibilities, but we still needed his input and knowledge for plenty of details.

I don't know what more to say about him other than he was the guy that we had the most contact with (by **far**) throughout the conference.

### Eric Floehr

Eric was the volunteer organizer, and he was the one that we sent all of the volunteers to so he could put them where he needed them.

Eric was also in charge of the payment of the invoice. This year it was billed in OSC's name, which seemed to work out, as it's an expense we can present to E-Council the following year. However, ultimately it was Eric who cut the check to the Union for the conference expenses.

# OSC's Pre-convention outreach and preparation

##

#### TODO: tedliosu, delgeez - expand here

## Emotional Support Dog

We were asked if Emotional support dogs were allowed in the Union, even though they were not an ADA protected service. The response we got from the Union was that if they weren't part of the ADA protected services, they were not allowed in the Union.

# Walkthrough

Here is a breakdown of the day-to-day events of the conference, and what happened this year.

## Friday

Friday started at 18:00 and went until 22:00. When we got there, all of the tables and chairs were already set up, and there was a minimal amount of work for us to do in that regard.

### A/V

The main part of Friday was the A/V setup. Carl came a bit late at 19:00, and arrived at the dock with his car full of his equipment. There was a bit of confusion as it was mentioned that Carl would be shipping some of equiment ahead of him, however this was not the case. He drove all of his equipment with him, so when we asked the Union to search for his shipped equipment, they were starting to freak out because they couldn't find it. Obviously they couldn't find it because it wasn't there!

During the setup, Carl made sure that he had the rooms set up exactly how he wanted them, and set up and tested all of the equipment in all of the rooms. There was a case where he tested audio, but didn't test video, and there were some video issues in Cartoon 1 as a result. Next year, I would hope that the setup would go quicker for audio, and the video be able to be tested as well.

However, there was time to test Saturday as well, as detailed below.

#### TODO: EDT - expand here

### Programs

We ordered 450x 12-page programs from UniPrint for delivery on Friday. They were delivered Friday, unfortunately, UniPrint was only open till 18:00, and that's when we got there. So if we had gotten there a bit sooner, we could have picked them up on time, but that wasn't the case, as was fleshed out below. We were told that we could access them at 10:00 the following day, but you'll see what happened there.

## Saturday

Saturday started at 07:30 and went until 19:00.

### A/V

There's always something to say about A/V. Saturday, we had some video flickering in the Cartoon rooms, and the regular Video-in wasn't working due in part to NDV's video splitter. Besides that, there were a couple wireless transitions that went fine, and generally if we needed them, they came running.

During the beginning of the day, after we got the doors unlocked (see below) we had the NDV crew do tests of the other two rooms during the registration period, and the keynote talk in Cartoon 1&2. So the Barbie Tootle and Susan Sharer rooms were being set up during the beginning of the conferences, since there were no talks until 10:30.

#### TODO: EDT - expand here

### Volunteers

We only had one volunteer show up for OSC, and we were able to fill out the Volunteer sheets from E-Council and have Brian sign them at the end of the day. We were also able to count the officer's hours as volunteer hours, with a maximum of 40 for the event.

### Programs

This could turn into a long story, but since we didn't pick up the programs from UniPrint on Friday, we needed to do that early Saturday. But while the bookstore was open at 10:00, UniPrint themselves wasn't available. However, after about five or six hours of working with the Building Manager (Jess <3) and Hali, we were able to get ahold of someone at UniPrint who could give us the authorization to go through their inventory to find our programs.

What was most disappointing about this is that OSC volunteered to coordinate getting the programs. Although the program design was late in getting to us, if we had been able to get UniPrint to get it to us earlier, we would've given us more time to get them. However, I would've thought that if the programs were in the Union, the Building Manager could have gotten them for us.

### Food

There was nothing wrong with the catering, it came out just as it said on the flyer - 8:00 for the breakfast, and 2:30 for everything else.

However, since there was a break between 1:00 and 2:30, a lot of people decided to go out to somewhere on High and get lunch there. I went to Pita Pit, and, like always, did _not_ regret it one bit.

### Doors

The doors were locked due to a system reboot gone [haywyre](https://www.youtube.com/watch?v=1oLTvCCQp-c), and we needed them manually unlocked so were could access them.

## Sunday

Sunday was from 10:30 - 19:00.

There wasn't much that happened Sunday except tear-down which even then was uneventful.

### Load-out

We figured out we had a bit of extra time, but we didn't need it. However, we didn't tell Carl that. We were able to get him done with the load-out in an hour. The Union A/V team got in and out of the rooms with their equipment quickly and accurately, which was very nice.

### Plates

The Catering forgot plates for the snacking brownies and cookies that were put out in the afternoon. One call to the building manager changed that.

### Parking passes

We were given parking passes for the volunteers, speakers, and organizers of the event. The ones that were used were given out and were valid for one exit from the parking garage. We were able to turn them back in at the end of Sunday, instead of waiting until after the event.

# Post-event

We are having an officers post-mortem meeting (along with a pre-semester component) to review the event.

## Next Years reservation

After the event, Brian requested that we make the reservation for the same setup for the 2018 year. He said that the most in advance that a student org can make a reservation is one year, so right after the event is the soonest that making a reservation would be feasible.

## Payment

We recieved the invoice the following Tuesday, and passed it on to Eric, who - even though it was billed to OSU - is going to cut a check directly to the Union. It makes it easier for our accounts.

The programs were paid for by the club originally (will be covered annually by club) and Eric was to reimbuse the club, this process took way longer than expected and was prolonged due to poor communication and the Club's mail management. Issues with programs payment can be avoided if the reimbursement is taken care of as soon as possible, and mail is properly configured.

# Conclusion

All-in-all this was a great event. The biggest issue (the program delays) was mostly our fault, and everything else went fine. Our outreach efforts were not very effective, and we might find a better was to do outreach, especially in the summer.
