# `opensource@cse.ohio-state.edu`

This is the mailing list where we will be doing most of our interaction with the public. This is an open mailing list that anyone can join, and anyone can be banned from. This is a list for discussions and announcements, for calls for volunteers, and donation requests.

- Front Page: http://mailman.cse.ohio-state.edu/mailman/listinfo/opensource
- Archives: http://mailman.cse.ohio-state.edu/pipermail/opensource/
- Moderator Interface: http://mailman.cse.ohio-state.edu/mailman/admin/opensource

## Using the list

It's pretty easy to use the list, all you have to do is email it like it's the primary recipient of the message. There is no admin/mod/announcement web interface for sending mail (I haven't come across it anyways).

## Administrators

This should be the BDFL and the Vice Chancellor

## Moderators

These should be all other officers. If necessary, the advisors can also be moderators. There would have to be extenuating circumstances to have anyone other than the officers or advisors as a moderator.

## Announcements

This list is mainly for announcements from the leadership. There should be announcements for every club meeting, every event (PyOhio, Makeathon, etc.), and any special communication that would be required.

### Templates

TODO:

- Meeting Template
- Event Template
- Volunteer Template
- Other Template

## General Discussion

However, in order to make sure that the list is getting eyeballs, we have to make sure that we breathe some life into it. This works best when a mailing list is used for general-purpose discussion.

I realize that this is dangerous, and some regulations need to evolve on how to govern the content of the mailing list. Purely technical content would be boring to most people (as we're not a project per se), and political content is just asking for trouble. The best way to put this list to use would be to spread news or events, or what I like to call "topical" discussion.

Once again, this list needs to be watched closely, however, the stated rules should be kept simple: 'Be Excellent To Each Other' seems to do well enough in most situations. Once you start getting into specifics, you're just asking for trouble.

# Other Docs

- `opensource-announce@cse.ohio-state.edu` (officers@)
- Systems' Mailing List Administration documentation
