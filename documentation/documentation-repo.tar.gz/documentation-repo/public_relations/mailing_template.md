# Mailing Template

When reaching out to companies, a PR officer should use a template
to structure communications.

## Initial Contact

> {@greeting} {@contact},
>
> My name is {@name}, and I am the {@position} for the
> Open Source Club at The Ohio State University. The club was wondering if you might
> be interested in coming in for a talk. Talks can be anything
> related to free software or open source --- community, projects,
> challenges, etc. --- and can last from 30-45 minutes. Talks
> take place at {@talk\_time}, {@talk\_place} on {@talk\_day}.
>
> If {@contact || @company} is interested in bringing someone in,
> please send a response to {@club\_email} or reply to this one.
>
> {@conclusion},
> {@name}

## Follow-up Email

If the company is interested in giving a talk, send something
along these lines:

> {@greeting} {@contact},
>
> Glad you can come in. Here are the dates we have open:
>
> {@open\_dates}
>
> If possible, we would like to have a summary at least a week prior
> to your talk. This allows us to send out information and bring more
> students in. Also, please let us know in advance if you plan to
> provide anything for attendees to eat.
>
> {@conclusion},
> {@name}

If there are circumstances unique to the presenter, take inspiration
from these templates for how to follow up rather than using them
verbatim.
